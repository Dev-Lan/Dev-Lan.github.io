#pragma once
// tiny util class, probably not great design, but conversions annoy me and are easy to screw up.

class Convert {
public:
	
inline static Vector3 to3D(const Vector2 v)
{
	return Vector3(v.x, 0, v.y);
}

inline static Vector2 to2D(const Vector3 v)
{
	return Vector2(v.x,v.z);
}

};