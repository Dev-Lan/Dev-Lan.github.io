#pragma once
#include <G3D/G3DAll.h>
#include <assert.h>
#include "Convert.hpp"

class Scene2D {
	struct disc{
		Vector2 pos;
		float radius;
	};

public:
	Scene2D() {	}
	Scene2D(
		const std::vector< Vector2 >& pos,
		const std::vector< float >& radius,
		const Vector2& topRight,
		const Vector2& botLeft
		);

	/// used to check if there is a free path from point A to B if you are a disc of size R.
	/// Size R=0 indicates you are just checking a point.
	bool collisionFreeDisc(const Vector2& A, const Vector2& B, float R) const;

	/// only checks collision with specific sphere.
	bool collisionFreeDisc(const Vector2& A, const Vector2& B, float R, int sphereIndex) const;

	/// checks if a point is in an obstacle.
	bool collisionFreeDisc(const Vector2& p, float r) const;

	void render3D(RenderDevice* rd) const;

	void addSphere(const Vector2& p, float r);

	/// defines bounding rect
	Vector2 topRight; // (max, max)
	Vector2 botLeft; // (min, min)


	/// circular obstacles
	std::vector< disc > _discs; // I'd prefer this was protected, but nah.

protected:

	/// todo line segment obstacles

	/// todo spatial collision lookup.
};