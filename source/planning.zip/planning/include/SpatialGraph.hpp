#pragma once
#include <map>
#include <unordered_set>
#include <G3D/G3DAll.h>

class GraphNode {
public:
	GraphNode() {	}
	GraphNode(
		float x,
		float y
		) :
			pos(x,y),
			G(-1),
			H(-1)
	{

	}
	GraphNode(
		const Vector2& pos
		) :
			pos(pos),
			G(-1),
			H(-1)
	{

	}

	Vector2 pos;
	std::vector< GraphNode* > children;
	// useful for search algorithm.
	float G;
	float H;
};

class SpatialGraph {
public:
	SpatialGraph() {	}

	// breaking rule of 3/5, lazy and constrained by time, because school.
	~SpatialGraph();

	/// returns shortest path using weighted A*, by default k=1 resulting in regular A*
	std::vector< GraphNode* > weightedAStar(GraphNode* start, GraphNode* goal, float k=1);

	/// helper function for creating path from dictionary lookup
	std::vector< GraphNode* > constructPath(std::map< GraphNode*, GraphNode* >& cameFrom, GraphNode* goalNode);


protected:
	std::vector< GraphNode* > _nodes;

};