#pragma once
#include <G3D/G3DAll.h>
#include <iostream>
#include <sstream>
#include "PreviewPlane.hpp"
#include "AttemptTexture.hpp"
#include "PRM.hpp"
#include "Scene2D.hpp"
#include "Convert.hpp"

class App : public GApp {
public:
	
	App(const GApp::Settings& settings = GApp::Settings());
	
	virtual void onInit() override;

	virtual void onUserInput(UserInput *ui) override;
	virtual void onSimulation(RealTime rdt, SimTime sdt, SimTime idt) override;

	virtual void onGraphics3D(RenderDevice* rd, Array<shared_ptr<Surface> >& surface3D) override;
	virtual void onGraphics2D(RenderDevice* rd, Array<Surface2D::Ref>& surface2D) override;

protected:
	std::shared_ptr< PreviewPlane > _previewPlane;
	std::shared_ptr< Texture > _groundTileTexture;
	std::shared_ptr< Texture > _groundTileTextureNRM;

	bool _viewRoadMap;
	bool _viewPath;

	std::shared_ptr< Scene2D > _scene;
	std::shared_ptr< PRM > _prm;


	// start goal
	Vector2 _startPos;
	Vector2 _goalPos;
	std::vector< GraphNode* > _currentPath;
	// used to animate agent
	Vector2 _agentPos;
	float _agentRadius;
};
