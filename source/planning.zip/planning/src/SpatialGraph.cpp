#include "SpatialGraph.hpp"

SpatialGraph::~SpatialGraph()
{

}

std::vector< GraphNode* > SpatialGraph::weightedAStar(GraphNode* start, GraphNode* goal, float k)
{
	// I assume start and goal exist in this graph, I also don't check. I like to live dangerously.

	// The title of this function is a lie I only have the motivation for BFS.
	// clear scores of all nodes.
	for (unsigned int i=0; i < _nodes.size(); i++) {
		_nodes[i]->G = -1;
		_nodes[i]->H = -1;
	}


	// closed set uptimization, since our heuristic is consistent
	// std::unordered_set< GraphNode* > closedSet;
	std::queue< GraphNode* > openQ; // todo priority queueueueueu
	// std::unordered_set< GraphNode* > openSet;
	start->G = 0;
	openQ.push(start);
	std::map< GraphNode*, GraphNode* > cameFrom;
	while (!openQ.empty()) {
		GraphNode* current = openQ.front();
		openQ.pop();
		if (current == goal) {
			return constructPath(cameFrom, goal);
		}
		for (unsigned int i=0; i < current->children.size(); i++) {
			if (current->children[i]->G == -1) {
				current->children[i]->G = current->G + 1;
				cameFrom[current->children[i]] = current;
				openQ.push(current->children[i]);
			}

		}
	}
	std::cout << "ERROR : No path found, died, turned into ghost. Exiting." << std::endl;
	std::vector< GraphNode* > badPath;
	badPath.push_back(goal);
	return badPath;
}

std::vector< GraphNode* > SpatialGraph::constructPath(std::map< GraphNode*, GraphNode* >& cameFrom, GraphNode* goalNode)
{
	// NOTE : the list is ordered with goal first and start node at the end
	std::vector< GraphNode* > result;
	result.push_back(goalNode);
	GraphNode* currentNode = goalNode;
	while (cameFrom.count(currentNode) != 0) {
		currentNode = cameFrom[currentNode];
		result.push_back(currentNode);
	}
	return result;
}