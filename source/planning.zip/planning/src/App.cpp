#include "App.hpp"

// using namespace std;

App::App(const GApp::Settings& settings) : GApp(settings) {
	renderDevice->setColorClearValue(Color3(0.15, 0.15, 0.15));
}

void App::onInit() {
	GApp::onInit();

	if (DEBUG_ENABLED) {
		std::cout << "debug defined" << std::endl;
		createDeveloperHUD();
		debugWindow->setVisible(false);
		developerWindow->setVisible(false);
		developerWindow->cameraControlWindow->setVisible(false);
		developerWindow->sceneEditorWindow->setVisible(false);
	}
	showRenderingStats = false;
	_groundTileTexture = AttemptTexture::attemptTextureFromFile(GROUND_TILE_TEXTURE);
	_groundTileTextureNRM = AttemptTexture::attemptTextureFromFile(GROUND_TILE_TEXTURE_NRM);
	_previewPlane = std::shared_ptr< PreviewPlane > (new PreviewPlane(_groundTileTexture, _groundTileTextureNRM, 20, 20, 2, 2));
	
	// camera
	activeCamera()->setPosition(Vector3(0,15,-3));
	activeCamera()->lookAt(Vector3(0,0,0));
	
	_viewRoadMap = false;
	_viewPath = false;
	// init scene
	std::vector< Vector2 > obstPos;
	obstPos.push_back(Vector2(0,0));

	std::vector< float > obstR;
	obstR.push_back(2.f);
	Vector2 tr(10,10);
	Vector2 bl(-10, -10);
	std::cout << "initializing scene..." << std::endl;
	_scene = std::shared_ptr< Scene2D > (new Scene2D(obstPos, obstR, tr, bl));
	std::cout << "initializing road map..." << std::endl;
	_agentRadius = 1.f;
	_prm = std::shared_ptr< PRM > (new PRM(_scene, 100, 4, _agentRadius));
	std::cout << "roadmap complete." << std::endl;
	std::cout << "beginning search for path" << std::endl;
	_startPos = Vector2(-9,-9);
	_agentPos = _startPos;
	_goalPos = Vector2(9,9);
	_currentPath = _prm->getPath(_startPos, _goalPos);
	std::cout << "path found" << std::endl;
}


void App::onUserInput(UserInput *ui) {
	GApp::onUserInput(ui); // needed for widgets to advance (camera manipulators, GUIs)

	if (ui->keyPressed(GKey('1'))) {
		_viewRoadMap = !_viewRoadMap;
	}

	if (ui->keyPressed(GKey('2'))) {
		_viewPath = !_viewPath;
	}

	if (ui->keyPressed(GKey('r'))) {
		_agentPos = _startPos;
	}

	if (ui->keyPressed(GKey::LEFT_MOUSE)) {
		int x = ui->mouseXY().x;
		int y = ui->mouseXY().y;
		Ray selectRay = activeCamera()->worldRay(x,y, renderDevice->viewport());
		Plane groundPlane(Vector3(0,1,0), Point3(0,0,0));
		Vector3 intersect = selectRay.intersection(groundPlane);
		
		if (ui->keyDown(GKey::LSHIFT)) {
			_goalPos = Convert::to2D(intersect);
			_agentPos = _startPos;
		} else {
			_startPos = Convert::to2D(intersect);
			_agentPos = _startPos;
		}
		_currentPath = _prm->getPath(_startPos, _goalPos);
	}

	if (ui->keyDown(GKey(' '))) {
		int x = ui->mouseXY().x;
		int y = ui->mouseXY().y;
		Ray selectRay = activeCamera()->worldRay(x,y, renderDevice->viewport());
		bool hitSphere = false;
		int sphereIndex = -1;
		for (unsigned int i=0; i < _scene->_discs.size(); i++) {
			Sphere s(Convert::to3D(_scene->_discs[i].pos), _scene->_discs[i].radius);
			if ( !std::isinf(selectRay.intersectionTime(s)) ) {
				hitSphere = true;
				sphereIndex = i;
				break;
			}
		}

		if (hitSphere) {
			_scene->_discs[sphereIndex].radius += 0.01f;
		} else {
			Plane groundPlane(Vector3(0,1,0), Point3(0,0,0));
			Vector3 intersect = selectRay.intersection(groundPlane);
			_scene->addSphere(Convert::to2D(intersect) , 0.1f);
			sphereIndex = _scene->_discs.size() - 1;
		}
		if (_prm->updateGraphAfterNewSphere(sphereIndex)) {
			// the function returns true if a change was made
			_currentPath = _prm->getPath(_startPos, _goalPos);
		}
	}





	// if(ui->keyDown(GKey('s'))){
	// 	_previewPlane->d_kd *= 1.01f;
	// 	std::cout << "KD : " << _previewPlane->d_kd << std::endl;
	// }

	// if(ui->keyDown(GKey('z'))){
	// 	_previewPlane->d_ks *= .99f;
	// 	std::cout << "KS : " << _previewPlane->d_ks << std::endl;
	// }
	// if(ui->keyDown(GKey('x'))){
	// 	_previewPlane->d_ks *= 1.01f;
	// 	std::cout << "KS : " << _previewPlane->d_ks << std::endl;
	// }

// if (ui->keyDown(GKey::LEFT_MOUSE)) {
// }
// }

// if(ui->keyPressed(GKey(' '))){
// }

}


void App::onSimulation(RealTime rdt, SimTime sdt, SimTime idt) {
	GApp::onSimulation(rdt, sdt, idt); // need for widgets to advance (camera manipulators, GUIs)
	
	Vector2 vtg = _goalPos - _agentPos;
	float distSquaredToGoal = vtg.dot(vtg);
	const float eps = .1f;
	if (distSquaredToGoal > eps * eps) {
		// const float agentSpeed = 10.f; // usain bolt level sprinting
		const float agentSpeed = 5.f; // Devin level sprinting
		// const float agentSpeed = 1.4f; // average walker
		Vector2 farthestGoal = _goalPos; // If something gets screwed up, and no valid goal is find, just go to final goal. Walls be damned.
		for (unsigned int i=0; i < _currentPath.size(); i++) {
			if (_scene->collisionFreeDisc(_agentPos, _currentPath[i]->pos, _agentRadius)) {
				farthestGoal = _currentPath[i]->pos;
				break;
			}
		}
		Vector2 v = (farthestGoal - _agentPos).direction();
		_agentPos += v * agentSpeed * rdt;
	}


}



void App::onGraphics3D(RenderDevice* rd, Array<shared_ptr<Surface> >& surface3D) {
	swapBuffers();
	rd->clear();
	_previewPlane->render3D(rd);
	_scene->render3D(rd);

	// start/goal vis
	const float sphereRadius = 0.25f;
	Sphere start(Convert::to3D(_startPos), sphereRadius);
	Draw::sphere(start, rd, Color3(.8,.9,.14), Color4::clear());
	Sphere goal(Convert::to3D(_goalPos), sphereRadius);
	Draw::sphere(goal, rd, Color3(.2,.6,.21), Color4::clear());

	// path vis
	if (_viewPath) {
		for (unsigned int i=0; i < _currentPath.size()-1; i++) {
			LineSegment ls = LineSegment::fromTwoPoints(Convert::to3D(_currentPath[i]->pos), Convert::to3D(_currentPath[i+1]->pos));
			Draw::lineSegment(ls, rd, Color3::orange());
		}
	}
	// entire roadmap graph
	if (_viewRoadMap) {
		_prm->render3D(rd);
	}

	// draw agent
	Sphere agent(Convert::to3D(_agentPos), _agentRadius);
	Draw::sphere(agent, rd, Color4(.2,.9,.87,.5));
}


void App::onGraphics2D(RenderDevice* rd, Array<Surface2D::Ref>& posed2D) {
	Surface2D::sortAndRender(rd, posed2D);

// Array<Vector2> circle;
// int numberOfVerts = 20;
// Vector2 center(500,150);
// double tau = 6.28;
// double radius = 100;
// for(int i=0; i<numberOfVerts; ++i){
// double percent = (double) i / (double) numberOfVerts;
// double x = radius*sin(percent*tau) + center.x;
// double y = radius*cos(percent*tau) + center.y;
// circle.append(Vector2(x,y));
// }
// Draw::poly2D(circle, rd, Color3::blue());
}




