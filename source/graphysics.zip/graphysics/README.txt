##########################################################################################
# Name:                            Devin Lange                                           #
##########################################################################################
# Email Adress:                    lange604@umn.edu                                      #
##########################################################################################

To compile with G3D-10 you should be able to edit the ice.txt file in this directory
and then just run icompile.

Alternatively for a .app compilation of this project that should run on Mac you can go to

http://dev-lan.github.io/classes/5611csci-hw2.html