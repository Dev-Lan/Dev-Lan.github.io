#include "App.hpp"

// using namespace std;

App::App(const GApp::Settings& settings) : GApp(settings) {
	renderDevice->setColorClearValue(Color3(0.15, 0.15, 0.15));
	_emitter = std::shared_ptr< DiscEmitter >(new DiscEmitter(0.5, 50, 1, 0.5));
	_waterSim = std::shared_ptr< Water > (new Water());
	_advanceSim = true;
	_sloMo = false;
	_refract = false;
	_onShallowWaterMode = false;
}

void App::onInit() {
	GApp::onInit();

	if (DEBUG_ENABLED) {
		std::cout << "debug defined" << std::endl;
		createDeveloperHUD();
		debugWindow->setVisible(false);
		developerWindow->setVisible(false);
		developerWindow->cameraControlWindow->setVisible(false);
		developerWindow->sceneEditorWindow->setVisible(false);
	}
	showRenderingStats = false;
	_groundTileTexture = AttemptTexture::attemptTextureFromFile(GROUND_TILE_TEXTURE);
	_groundTileTextureNRM = AttemptTexture::attemptTextureFromFile(GROUND_TILE_TEXTURE_NRM);
	_previewPlane = std::shared_ptr< PreviewPlane > (new PreviewPlane(_groundTileTexture, _groundTileTextureNRM, 10, 10, 10, 10)); // 14 14 2 2 for w
	
	_shallowWaterSim = std::shared_ptr< ShallowWater > (new ShallowWater(.1, 80, 80, _groundTileTexture));

	activeCamera()->setPosition(Vector3(0,2,-5));
	activeCamera()->lookAt(Vector3(0,0,0));

	_camManipulator = FirstPersonManipulator::create();
	_camManipulator->setMoveRate(5.6f);
	
	setCameraManipulator(_camManipulator);
	addWidget(_camManipulator);
	_lastDT = 0;
	_timeElapsed = 0;
	_framesElapsed = 0;
}


void App::onUserInput(UserInput *ui) {
	GApp::onUserInput(ui); // needed for widgets to advance (camera manipulators, GUIs)

	// time dependent emitter.

	if(ui->keyDown(GKey('1'))) {
		_waterSim->_posList.clear();
		_waterSim->_velList.clear();
	}


	if (ui->keyDown(GKey(' '))){
		// add some water
		if (_onShallowWaterMode) {
			_shallowWaterSim->addWater(activeCamera()->frame().lookRay(), 4.f, .4f);
		} else {
			std::vector< Particle > newParticles = _emitter->spawnParticles((_lastDT), Ray(Point3(0,5,-1), Vector3(0,0,1)));
			for(unsigned int i=0; i < newParticles.size(); i++) {
				_waterSim->addDrop(newParticles[i].pos, newParticles[i].vel);
			}
		}
	}

	if (ui->keyPressed(GKey('2'))) {
		_shallowWaterSim->reset();
	}

	if (ui->keyPressed(GKey('3'))) {
		_onShallowWaterMode = !_onShallowWaterMode;
	}

	if (ui->keyPressed(GKey('p'))){
		// _waterSim->_posList.clear();
		_advanceSim = !_advanceSim;
	}

	if (ui->keyPressed(GKey('o'))) {
		_sloMo = !_sloMo;
	}

	if (ui->keyPressed(GKey('r'))) {
		_refract = !_refract;
	}

	if (ui->keyPressed(GKey('g'))) {
		_waterSim->gravityOn = !_waterSim->gravityOn;
	}

	if (ui->keyPressed(GKey('h'))) {
		_waterSim->constraintOn = !_waterSim->constraintOn;
	}	


}


void App::onSimulation(RealTime rdt, SimTime sdt, SimTime idt) {
	GApp::onSimulation(rdt, sdt, idt); // need for widgets to advance (camera manipulators, GUIs)
 	// const float prefDt = 0.002;
 	_framesElapsed++;
	_timeElapsed += rdt;
	if (_framesElapsed % 10 == 0) {
		_instantaneousFramerate = 1.f / rdt;
	}

 	float dt = rdt;
 	if (_sloMo) {
 		dt *= 0.1f;
 	}
 	if (_onShallowWaterMode) {
	 	const int numSteps = 20;
	 	if (_advanceSim) {
	 		for (int i=0; i < numSteps; i++) {
			 	_shallowWaterSim->update(dt / (float) numSteps);
	 		}
	 	}
	 } else {
	 	if (_advanceSim) {
		 	_waterSim->advanceSimulation(dt);
	 	}
	 }
 	_lastDT = rdt;
}



void App::onGraphics3D(RenderDevice* rd, Array<shared_ptr<Surface> >& surface3D) {
	swapBuffers();
	rd->clear();
	_previewPlane->render3D(rd);
	if (_onShallowWaterMode) {
		_shallowWaterSim->render3D(rd, _refract);
	} else {
		_waterSim->draw(rd);
	}
}


void App::onGraphics2D(RenderDevice* rd, Array<Surface2D::Ref>& posed2D) {
	Surface2D::sortAndRender(rd, posed2D);

	std::string fps = std::to_string(_instantaneousFramerate);
	fps = fps.substr(0, 5);

	debugFont->draw2D(rd, fps.c_str(), Point2(0,0), 48, Color3::white());
	fps = std::to_string(_framesElapsed / _timeElapsed);
	fps = fps.substr(0, 5);
	debugFont->draw2D(rd, fps.c_str(), Point2(0,50), 48, Color3::white());
}




