#include "Water.hpp"

// m_radius = 0.20;
// m_neighborhoodRadius = 1;
// m_k = 0.7;
// m_nearK = 1.75;
// m_prefDensity = 10;
// m_parameterToTune = 0;
void Water::advanceSimulation(double timestep){
	// TODO don't do in place...
	for (int i=0; i < _posList.size(); i++) {
		// add gravity
		if (gravityOn) {
			_velList[i] += m_gravity * timestep;
		}
		Vector3 oldPos = _posList[i];
		_posList[i] += _velList[i] * timestep;
		// water forces

		double density = 0;
		double nearDensity = 0;
		// TODO : spatial data structure
		for(int j=0; j<_posList.size(); j++){
			if(i != j){
				double distance = (_posList[i] - _posList[j]).length();
				double q = distance / m_neighborhoodRadius;
				if(q < 1){
					density += (1-q) * (1-q);
					nearDensity += (1-q) * (1-q) * (1-q);
				}
			}
		}
		double pressure	= m_k*(density - m_prefDensity);
		double nearPressure = m_nearK*nearDensity; 
		Vector3 thisDisplacement(0,0,0);
		// TODO : this can probably be moved into one loop.
		for(int j=0; j<_posList.size(); ++j){
			if(i != j){
				double distance = (_posList[i] - _posList[j]).length();
				double q = distance / m_neighborhoodRadius;
				if(q < 1){
					double magnitude = timestep*timestep * (pressure*(1-q) + nearPressure*(1-q)*(1-q));
					Vector3 unitVector = (_posList[j] - _posList[i]).directionOrZero(); 
					Vector3 displacement = (magnitude/2)*unitVector; // the 2 division is because this force will be found again
					_posList[j] += displacement;
					thisDisplacement -= displacement;
				}
			}
		}
		_posList[i] += thisDisplacement;
		// compute velocity.
		_velList[i] = (_posList[i] - oldPos) / timestep;

		// collision detection
		if (constraintOn) {
			const float restitution = -0.15f;

			if (_posList[i].y < m_radius) {
				_posList[i].y = m_radius;
				_velList[i].y *= restitution;
			}

			if (_posList[i].x < -1) {
				_posList[i].x = -1;
				_velList[i].x *= restitution;
			}
			if (_posList[i].x > 1) {
				_posList[i].x = 1;
				_velList[i].x *= restitution;
			}
			if (_posList[i].z < -1) {
				_posList[i].z = -1;
				_velList[i].z *= restitution;
			}
			if (_posList[i].z > 1) {
				_posList[i].z = 1;
				_velList[i].z *= restitution;
			}
		}

	}

	_posGPU.update(_posList);
	// TODO get these in sorted order.
	Array< int > cpuIndices;
	cpuIndices.reserve(_maxParticles);
	for (int i=0; i < _maxParticles; i++) {
		if (i < _posList.length()) {
			cpuIndices.append(i);
		} else {
			cpuIndices.append(0);
		}
	}
	_indices.update(cpuIndices);
	
}

void Water::draw(RenderDevice* rd){
 //	// for (WaterGrid::Iterator i = m_drops.begin(); i != m_drops.end(); ++i) {
 //	//	 i->draw(rd, m_sphereInstance);
 //	// }
	// for(int i=0; i < drops.size(); ++i){
 //		Sphere s(.04);
	// 	drops[i].draw(rd, s);
	// }
	rd->pushState();
	{
		rd->setCullFace(CullFace::NONE);
		Args args;
		args.setUniform("particleWidth", m_radius);
		const CoordinateFrame cframe = rd->cameraToWorldMatrix();
		args.setUniform("camPos", Vector3(cframe.translation.x, cframe.translation.y, cframe.translation.z));
		args.setAttributeArray("vert", _posGPU);
		args.setIndexStream(_indices);
		args.setPrimitiveType(PrimitiveType::POINTS);
		LAUNCH_SHADER(WATER_SHADER, args);
	}
	rd->popState();

}

void Water::initGeometry()
{
	// intialize data on graphics card to be the right size.
	Array< Vector3 > tmplist;
	tmplist.reserve(_maxParticles);
	for (int i=0; i < _maxParticles; i++) {
		tmplist.append(Vector3(0,0,0));
	}
	Array< int > tmplist3;
	tmplist3.reserve(_maxParticles);
	for (int i=0; i < _maxParticles; i++) {
		tmplist3.append(0);
	}

	_vbuf = VertexBuffer::create(_maxParticles * (sizeof(Vector3) + sizeof(int)), VertexBuffer::WRITE_EVERY_FRAME);
	_posGPU = AttributeArray(tmplist, _vbuf);
	_indices = IndexStream(tmplist3, _vbuf);

}
