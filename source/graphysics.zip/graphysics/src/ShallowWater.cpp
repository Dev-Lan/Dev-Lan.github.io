#include "ShallowWater.hpp"

void ShallowWater::render3D(RenderDevice* rd, bool refract)
{
	rd->pushState();
	{
		// glPointSize(3);
		rd->setCullFace(CullFace::NONE);
		rd->setBlendFunc(Framebuffer::COLOR0, RenderDevice::BLEND_SRC_ALPHA, RenderDevice::BLEND_ONE_MINUS_SRC_ALPHA, RenderDevice::BLENDEQ_ADD);
		Args args;

		args.setUniform("tex", _groundTexture, Sampler::video());

		args.setUniform("K_A", Color3(.1, .1, .2));
		args.setUniform("K_D", Color3(.2, .2, .9));
		args.setUniform("K_S", Color3(.7, .7, .7));
		args.setUniform("alpha", 100.f);

		args.setUniform("shouldRefract", refract);

		args.setMacro("NUM_POINT_LIGHTS", (int)_lightPositions.size());
		for (unsigned int i=0; i < _lightPositions.size(); i++) {
			args.setArrayUniform("pointLights", i, _lightPositions[i]);
			args.setArrayUniform("pointLightColors", i, _lightColors[i]);
			args.setArrayUniform("pointLightIntensities", i, _lightIntensities[i]);

		}
		Point3 camPosition = rd->cameraToWorldMatrix().translation;
		args.setUniform("camPos", camPosition);

		args.setAttributeArray("vert", _posGPU);
		args.setAttributeArray("norm", _normGPU);
		args.setIndexStream(_indices);
		args.setPrimitiveType(PrimitiveType::TRIANGLES);
		LAUNCH_SHADER(SHALLOW_WATER_SHADER, args);
	}
	rd->popState();

}

/*
	y1	y2	y3	y4
x1 [..	..	..	..]
x2 [..	..	..	..]
x3 [..	..	..	..]
x4 [..	..	..	..]

*/

void ShallowWater::update(float dt)
{
	std::vector< std::vector< float > > hmx;
	std::vector< std::vector< float > > umx;

	std::vector< std::vector< float > > hmy;
	std::vector< std::vector< float > > umy;
	for (int i = 0; i < _width; i++) {
		// this might be redundant, but whatever
		std::vector< float > row;
		std::vector< float > row2;
		std::vector< float > row3;
		std::vector< float > row4;
		for (int j=0; j <_length; j++) {
			row.push_back(0);
			row2.push_back(0);
			row3.push_back(0);
			row4.push_back(0);
		}
		hmx.push_back(row);
		umx.push_back(row2);
		hmy.push_back(row3);
		umy.push_back(row4);
	}

	// UPDATE PHYSICS
	const float g = 9.8;

	// HALF STEP

	// X - DIRECTION
	for (int i=0; i < _width-1; i++) {
		for (int j=0; j < _length; j++) {
			hmx[i][j] = (_h[i][j] + _h[i+1][j]) / 2.f
					- (dt/2.f) * (_ux[i+1][j] - _ux[i][j]) / _gridSize;
			umx[i][j] = (_ux[i][j] + _ux[i+1][j]) / 2.f
					- (dt/2.f) * (
							_ux[i+1][j] * _ux[i+1][j] / _h[i+1][j] + .5f * g * _h[i+1][j] * _h[i+1][j]
							- _ux[i][j] * _ux[i][j]	/ _h[i][j] - .5 * g * _h[i][j] * _h[i][j]
						) / _gridSize;
		}
	}

	// Y - DIRECTION
	for (int j=0; j < _length-1; j++) {
		for (int i=0; i < _width; i++) {
			hmy[i][j] = (_h[i][j] + _h[i][j+1]) / 2.f
					- (dt/2.f) * (_uy[i][j+1] - _uy[i][j]) / _gridSize;
			umy[i][j] = (_uy[i][j] + _uy[i][j+1]) / 2.f
					- (dt/2.f) * (
							_uy[i][j+1] * _uy[i][j+1] / _h[i][j+1] + .5f * g * _h[i][j+1] * _h[i][j+1]
							- _uy[i][j] * _uy[i][j]	/ _h[i][j] - .5 * g * _h[i][j] * _h[i][j]
						) / _gridSize;
		}
	}

	// FULL STEP
	const float damp = 0.25f;
	// unfortunately this damping consant is what prevents eventual water explosion,
	// so on slower computers it would have to be larger.

	// my explosion prevention hack
	// const float eps1 = 0.00001f; // stop small motions from causing integration explosion
	// const float eps2 = 0.000001f; // stop small motions from causing integration explosion
	

	// X - DIRECTION
	for (int i=0; i < _width-2; i++) {
		for (int j=0; j < _length; j++) {
			_h[i+1][j] -= dt * (umx[i+1][j] - umx[i][j]) / _gridSize;
			_ux[i+1][j] -= dt * ( damp * _ux[i+1][j] +
								umx[i+1][j] * umx[i+1][j] / hmx[i+1][j] + 0.5f * g * hmx[i+1][j] * hmx[i+1][j]
								- umx[i][j] * umx[i][j] / hmx[i][j] - 0.5f * g * hmx[i][j] * hmx[i][j]
							) / _gridSize;
			// if (_ux[i+1][j] < eps1) {
			// 	_ux[i+1][j] *= 0.5f;
			// }
			// if (_ux[i+1][j] < eps2) {
			// 	_ux[i+1][j] = 0;
			// }
		}
	}
	// Y - DIRECTION
	for (int j=0; j < _length-2; j++) {
		for (int i=0; i < _width; i++) {
			_h[i][j+1] -= dt * (umy[i][j+1] - umy[i][j]) / _gridSize;
			_uy[i][j+1] -= dt * ( damp * _uy[i][j+1] +
								umy[i][j+1] * umy[i][j+1] / hmy[i][j+1] + 0.5f * g * hmy[i][j+1] * hmy[i][j+1]
								- umy[i][j] * umy[i][j] / hmy[i][j] - 0.5f * g * hmy[i][j] * hmy[i][j]
							) / _gridSize;
			// if (_uy[i][j+1] < eps1) {
			// 	_uy[i][j+1] *= 0.5f;
			// }
			// if (_uy[i][j+1] < eps2) {
			// 	_uy[i][j+1] = 0;
			// }
		}
	}

	// HANDLE EDGE CASES

	// reflective
	// X - DIRECTION
	for (int j=0; j < _length; j++) {
		_h[0][j] = _h[1][j];
		_h[_width-1][j] = _h[_width-2][j];
		_ux[0][j] = -_ux[1][j];
		_ux[_width-1][j] = -_ux[_width-2][j];
	}

	// Y - DIRECTION
	for (int i=0; i < _width; i++) {
		_h[i][0] = _h[i][1];
		_h[i][_length-1] = _h[i][_length-2];
		_uy[i][0] = -_uy[i][1];
		_uy[i][_length-1] = -_uy[i][_length-2];
	}

	// UPDATE GRAPHICS CARD DATA
	Array< Vector3 > newPositions;
	for (int i=0; i < _width; i++) {
		for (int j=0; j < _length; j++) {
			Vector3 v(
				(i - _width / 2.f) * _gridSize,
				_h[i][j],
				(j - _length / 2.f) * _gridSize
				);
			newPositions.append(v);
		}
	}
	_posGPU.update(newPositions);
	Array< Vector3 > newNorms;
	for (int i=0; i < _width; i++) {
		for (int j=0; j < _length; j++) {
			Point3 p = newPositions[i*_width + j];
			// take average of 8 normals
			Vector3 norm(0,0,0);
			if (i > 0 && j > 0 && i < _width-1 && j < _length-1) {
				Vector3 v1 = newPositions[ (i-1) * _width + j-1]	- p;
				Vector3 v2 = newPositions[ (i-1) * _width + j]		- p;
				norm += v1.cross(v2);

				Vector3 v3 = newPositions[ (i-1) * _width + j+1]	- p;
				norm += v2.cross(v3);
				
				Vector3 v4 = newPositions[ i * _width + j+1]		- p;
				norm += v3.cross(v4);
				
				Vector3 v5 = newPositions[ (i+1) * _width + j+1]	- p;
				norm += v4.cross(v5);
				
				Vector3 v6 = newPositions[ (i+1) * _width + j]		- p;
				norm += v5.cross(v6);
				
				Vector3 v7 = newPositions[ (i+1) * _width + j-1]	- p;
				norm += v6.cross(v7);
				
				Vector3 v8 = newPositions[ i * _width + j-1]		- p;
				norm += v7.cross(v8);
				norm += v8.cross(v1);
			} else {
				// too lazy for edge cases...
				norm = Vector3(0,1,0);
			}
			newNorms.append(norm.direction());
		}
	}
	_normGPU.update(newNorms);

}

void ShallowWater::addWater(const Ray& ray, float amount, float radius)
{
	for (unsigned int i=0; i < _h.size(); i++) {
		for (unsigned int j=0; j < _h[i].size(); j++) {
			Point3 p(
				(i - _width / 2.f) * _gridSize,
				_h[i][j],
				(j - _length / 2.f) * _gridSize
				);
			float dist = ray.distance(p);
			if (dist < radius) {
				_h[i][j] += amount * (-(dist * dist) + radius * radius);
			}

		}
	}
}

void ShallowWater::reset() {
	for (int i=0; i < _width; i++) {
		for (int j=0; j < _length; j++) {
			_h[i][j] = 0.5f;
			_uy[i][j] = 0;
			_ux[i][j] = 0;
		}
	}
}


void ShallowWater::initGeometry()
{
	Array< Vector3 > tmplist;
	tmplist.reserve(_width * _length);
	for (int i = 0; i < _width * _length; i++) {
		tmplist.append(Vector3(0,0,0));
	}
	Array< int > tmplist2;
	tmplist2.reserve((_width-1) * (_length-1));
	for (int i=0; i < _width-1; i++) {
		for (int j=0; j < _length-1; j++) {
			tmplist2.append(i*_width + j);
			tmplist2.append((i+1)*_width + (j+1));
			tmplist2.append(i*_width + (j+1));

			tmplist2.append(i*_width + j);
			tmplist2.append((i+1)*_width + j);
			tmplist2.append((i+1)*_width + (j+1));
		}
	}
	_vbuf = VertexBuffer::create(_width * _length * (2 * sizeof(Vector3)) + sizeof(int) * tmplist2.size(), VertexBuffer::WRITE_EVERY_FRAME);
	_posGPU = AttributeArray(tmplist, _vbuf);
	_normGPU = AttributeArray(tmplist, _vbuf);
	_indices = IndexStream(tmplist2, _vbuf);

	// I should really make a more general light class.
	_lightPositions.push_back(Vector3(1.4,5,0));
	_lightColors.push_back(Color3(1.f, 1.f, 1.f));
	_lightIntensities.push_back(1.50f);

	_lightPositions.push_back(Vector3(-1.4,5,1.6));
	_lightColors.push_back(Color3(1.f, 1.f, 1.f));
	_lightIntensities.push_back(1.50f);

	_lightPositions.push_back(Vector3(-1.4,5,-1.6));
	_lightColors.push_back(Color3(1.f, 1.f, 1.f));
	_lightIntensities.push_back(1.5f);
}