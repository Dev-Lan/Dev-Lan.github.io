#pragma once
#include <G3D/G3DAll.h>
#include "config.hpp"

class ShallowWater
{
public:
	ShallowWater() {}

	ShallowWater(
		float gridSize,
		float width,
		float length,
		const std::shared_ptr< Texture >& groundTexture
		) :
			_gridSize(gridSize),
			_width(width),
			_length(length),
			_groundTexture(groundTexture)

	{
		// for (int i=0; i < _width; i++) {
		// 	std::vector< float > row;
		// 	std::vector< Vector2 > row2;
		// 	for (int j=0; j < _length; j++) {
		// 		if (i == 1) {
		// 			row.push_back(6);
		// 		} else if (i == 2) {
		// 			row.push_back(5.5);
		// 		} else {
		// 			row.push_back(5);
		// 		}
		// 		row2.push_back(Vector2(0,0));
		// 	}
		// 	_heightMap.push_back(row);
		// 	_uMap.push_back(row2);
		// }
		for (int i=0; i < _width; i++) {
			std::vector< float > row;
			std::vector< float > row2;
			std::vector< float > row3;
			for (int j=0; j < _length; j++) {
				// if (j < 10 && i < 10) {
					// row.push_back(.1 + -(i*j - 100) / 100.f);
				// } else {
					row.push_back(.5);
				// }
				row2.push_back(0);
				row3.push_back(0);
			}
			_h.push_back(row);
			_ux.push_back(row2);
			_uy.push_back(row3);
		}
		initGeometry();
	}

	void render3D(RenderDevice* rd, bool refract);

	void update(float dt);

	void addWater(const Ray& ray, float amount, float radius);

	void reset();

protected:
	void initGeometry();

	float _gridSize; // width of each individual cell

	// grid dimensions
	int _width; 
	int _length;

	std::vector< Vector3 > _lightPositions;
	std::vector< Color3 > _lightColors;
	std::vector< float > _lightIntensities;

	// std::vector< std::vector< float > > _heightMap;
	// std::vector< std::vector< Vector2 > > _uMap;

	std::vector< std::vector< float > > _h;
	std::vector< std::vector< float > > _ux;
	std::vector< std::vector< float > > _uy;

	AttributeArray _posGPU;
	AttributeArray _normGPU;

	IndexStream _indices;
	std::shared_ptr< VertexBuffer > _vbuf;
	
	// needed for hacky refraction
	std::shared_ptr< Texture > _groundTexture;


};