#pragma once
#include <G3D/G3DAll.h>
#include <iostream>
#include <sstream>
#include "PreviewPlane.hpp"
#include "AttemptTexture.hpp"
#include "Water.hpp"
#include "ShallowWater.hpp"
#include "DiscEmitter.hpp"



class App : public GApp {
public:
	
	App(const GApp::Settings& settings = GApp::Settings());
	
	virtual void onInit() override;

	virtual void onUserInput(UserInput *ui) override;
	virtual void onSimulation(RealTime rdt, SimTime sdt, SimTime idt) override;

	virtual void onGraphics3D(RenderDevice* rd, Array<shared_ptr<Surface> >& surface3D) override;
	virtual void onGraphics2D(RenderDevice* rd, Array<Surface2D::Ref>& surface2D) override;

protected:
	std::shared_ptr< PreviewPlane > _previewPlane;
	shared_ptr< Texture > _groundTileTexture;
	shared_ptr< Texture > _groundTileTextureNRM;
	shared_ptr< DiscEmitter > _emitter;
	std::shared_ptr< FirstPersonManipulator > _camManipulator;
	std::shared_ptr< Water > _waterSim;
	std::shared_ptr< ShallowWater > _shallowWaterSim;
	float _lastDT;
	bool _advanceSim;
	bool _sloMo;
	bool _refract;
	bool _onShallowWaterMode;

	float _timeElapsed;
	int _framesElapsed;
	float _instantaneousFramerate;

};
