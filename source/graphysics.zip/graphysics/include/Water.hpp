#ifndef Water_h
#define Water_h

#include <G3D/G3DAll.h>
// #include "Drop.hpp"
#include "config.hpp"

class Water {

  float m_radius;
  double m_neighborhoodRadius;
  double m_k;
  double m_prefDensity;
  double m_nearK;
  int m_parameterToTune; // TODO:: change this to an enum
  Sphere m_sphereInstance;
  Vector3 m_gravity;
  // FastSphere m_fastSphereInstance;

  // todo make this of new class. coordinate efforts!
  // typedef PointHashGrid<Drop, Drop> WaterGrid;
  // WaterGrid m_grid;

public:
	// Array<Drop> drops;

	Water() : m_neighborhoodRadius(1)
	{
		m_radius = 0.20;
		// neighborhoodRadius = 1;
		m_k = .7;
		m_nearK =  1.75;
		m_prefDensity = 10;
		m_parameterToTune = 0;
		m_sphereInstance = Sphere(Vector3(0,0,0), m_radius);
		// m_fastSphereInstance = FastSphere(m_radius, 2); // quality = 2
		m_gravity = Vector3(0, -9.8, 0);
		_maxParticles = 1000;
		gravityOn = true;
		constraintOn = true;
		initGeometry();
	}

	void addDrop(const Vector3& position){
		// m_drops.insert(Drop(position, m_radius));
		// drops.append(Drop(position, m_radius));
		if (_posList.length() < _maxParticles) {
			_posList.append(position);
		}
	}

	void addDrop(const Vector3& position, const Vector3& velocity){
		// drops.append(Drop(position, velocity, m_radius));
		if (_posList.length() < _maxParticles) {
			_posList.append(position);
			_velList.append(velocity);
		}
	}

	void advanceSimulation(double timestep);
	void draw(RenderDevice* rd);

	Array< Vector3 > _posList;
	Array< Vector3 > _velList;

	AttributeArray _posGPU; // positions on gpu

	IndexStream _indices;
	std::shared_ptr< VertexBuffer > _vbuf;

	int _maxParticles;

	void initGeometry();

	bool gravityOn;
	bool constraintOn;

	// getters
	// WaterGrid& getDrops(){ return m_drops; }


};

#endif