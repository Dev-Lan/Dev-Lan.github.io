#pragma once
#include <G3D/G3DAll.h>

// these are set by my compiler, but if you don't set that up, at least one of these lines should be uncommented
// #define DEBUG_ENABLED=true
// #define DEBUG_ENABLED=false

#if (DEBUG_ENABLED)
	const G3D::String DATA_DIR = "./";
#else
	const G3D::String DATA_DIR = "../Resources/"; // this should work for deploying on mac
#endif

const G3D::String TEXTURE_DIR = DATA_DIR + "textures/";
const G3D::String SHADER_DIR  = DATA_DIR + "shaders/";

const G3D::String LIT_TEX_NRM = SHADER_DIR + "textured.*";
const G3D::String WATER_SHADER = SHADER_DIR + "bbCircle.*";
const G3D::String SHALLOW_WATER_SHADER = SHADER_DIR + "shallowWater.*";

// const G3D::String GROUND_TILE_TEXTURE = TEXTURE_DIR + "hardwood.jpg";
const G3D::String GROUND_TILE_TEXTURE_NRM = TEXTURE_DIR + "hardwood_NRM.png";

const G3D::String GROUND_TILE_TEXTURE = TEXTURE_DIR + "nature_14022011jjk043_m.jpg";



// const G3D::String RUSTY_DIAMOND_METAL_TEXTURE_FILENAME = TEXTURE_DIR + "rusty_diamond_metal.jpg";
// const G3D::String RUSTY_DIAMOND_METAL_TEXTURE_FILENAME = TEXTURE_DIR + "rusty_diamond_metal.png";

