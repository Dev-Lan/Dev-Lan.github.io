#pragma once
#include <G3D/G3DAll.h>

// these are set by my compiler, but if you don't set that up, at least one of these lines should be uncommented
// #define DEBUG_ENABLED=true
// #define DEBUG_ENABLED=false

#if (DEBUG_ENABLED)
	const G3D::String DATA_DIR = "./";
#else
	const G3D::String DATA_DIR = "../Resources/"; // this should work for deploying on mac
#endif

const G3D::String TEXTURE_DIR = DATA_DIR + "textures/";
const G3D::String SHADER_DIR  = DATA_DIR + "shaders/";

const G3D::String LIT_TEX_NRM = SHADER_DIR + "textured.*";
const G3D::String BASIC_PARTICLE = SHADER_DIR + "basicParticle.*";
const G3D::String BB_TEX_SHADER = SHADER_DIR + "bbTextured.*";
const G3D::String BB_TEX_BALL_SHADER = SHADER_DIR + "bbTextured-ball.*";
const G3D::String BB_TEX_BUBBLE_SHADER = SHADER_DIR + "bbTextured-bubble.*";


const G3D::String GROUND_TILE_TEXTURE = TEXTURE_DIR + "hardwood.jpg";
const G3D::String GROUND_TILE_TEXTURE_NRM = TEXTURE_DIR + "hardwood_NRM.png";

const G3D::String GLYPH_MASK = TEXTURE_DIR + "stroke_grid_16.png";
// const G3D::String GLYPH_MASK = TEXTURE_DIR + "circle.png";
// const G3D::String GLYPH_MASK = TEXTURE_DIR + "sizeTest.png";

const G3D::String FIRE_COLOR1 = TEXTURE_DIR + "fireTexture1.png";

const G3D::String FIRE_COLOR2 = TEXTURE_DIR + "testFireTexture.png";
const G3D::String FIRE_COLOR3 = TEXTURE_DIR + "testFireTexture2.png";

const G3D::String BALL_TEXTURE = TEXTURE_DIR + "circle.png";

const G3D::String WATER_COLOR = TEXTURE_DIR + "water1.png";

const G3D::String FIREWORK_COLOR = TEXTURE_DIR + "fireworks1.png";

// Too lazy to put into one texture.
const G3D::String BUBBLE_TEXTURE1 = TEXTURE_DIR + "bubble1.png";
const G3D::String BUBBLE_TEXTURE2 = TEXTURE_DIR + "bubble2.png";
const G3D::String BUBBLE_TEXTURE3 = TEXTURE_DIR + "bubble3.png";
const G3D::String BUBBLE_TEXTURE4 = TEXTURE_DIR + "bubble4.png";





// const G3D::String RUSTY_DIAMOND_METAL_TEXTURE_FILENAME = TEXTURE_DIR + "rusty_diamond_metal.jpg";
// const G3D::String RUSTY_DIAMOND_METAL_TEXTURE_FILENAME = TEXTURE_DIR + "rusty_diamond_metal.png";

