#pragma once

class FireCell {
public:
	FireCell();
};