#pragma once
#include <math.h>
#include <vector>
#include <G3D/G3DAll.h>
#include "ParticleSystem.hpp"


// This class is moving sphere emitter that will emit particles on the shell of the sphere with some velocity pointing away from
// the center of the sphere. I created it for the firework particle system
class SphereEmitter {
public:
	SphereEmitter() {}
	SphereEmitter(float radius, float particlesPerSecond, float emitSpeed, const Vector3& pos, const Vector3& vel, const Vector3& gravity = Vector3(0,-9.8,0)) :
		_radius(radius),
		_particlesPerSecond(particlesPerSecond),
		_emitSpeed(emitSpeed),
		_pos(pos),
		_vel(vel),
		_gravity(gravity)
		{

		}

	void updatePosition(float dt);

	/// This function spawns appropriate particles.
	std::vector< Particle > spawnParticles(float dt);

	inline void setEmitSpeed(float emitSpeed) { _emitSpeed = emitSpeed; }
	inline void setParticlesPerSecond(float particlesPerSecond) { _particlesPerSecond = particlesPerSecond; }

protected:
	float _radius;
	float _particlesPerSecond;
	float _emitSpeed; // speed of particles coming off of 
	Vector3 _pos;
	Vector3 _vel;
	Vector3 _gravity;

};