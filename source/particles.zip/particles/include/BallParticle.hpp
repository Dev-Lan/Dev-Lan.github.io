#pragma once
#include "config.hpp"
#include "ParticleSystem.hpp"
#include "DiscEmitter.hpp"

class BallParticle : public ParticleSystem {
public:
	BallParticle() {	}

	BallParticle(
		const std::shared_ptr< Texture >& glyphTexture,
		int maxParticles = 100,
		float emitterRadius = 0.2,
		float particleSize = 0.05f,
		float maxSpeed = 10.f,
		float particleLifetime = 3.f, // indirectly controls speed of particle
		float particlesPerSecond = 5,
		const Vector3& gravity = Vector3(0, -9.8f, 0),
		float restitution = 0.7f
		) :
			_emitter(emitterRadius, particlesPerSecond, maxSpeed, 0.5f),
			_maxParticles(maxParticles),
			_glyphTexture(glyphTexture),
			_particleSize(particleSize),
			_particleLifetime(particleLifetime),
			_gravity(gravity),
			_restitution(restitution)
		{
			initGeometry();
		}



	virtual void render3D(RenderDevice* rd);

	/// Update the particle system by small timestep.
	virtual void update(float dt, const Ray& ray);

protected:
	/// Use parallel lists to avoid a copy when sending info to graphics card.
	Array< Vector3 > _posList;      // positions
	Array< Vector3 > _velList;      // velocities
	Array< float > _tList;          // time alive
	// Array< Vector2 > _texCoordList; // color tex coord lookup of width and depth.

	DiscEmitter _emitter;  // creates new particles

	AttributeArray _posGPU;      // positions on gpu
	// AttributeArray _tGPU;        // time on gpu
	// AttributeArray _texCoordGPU; // texCoord on gpu
	// AttributeArray _maskOffsetGPU; // texCoord on gpu
	IndexStream _indices;
	std::shared_ptr< VertexBuffer > _vbuf;

	int _maxParticles;  // max particles allowed, used to init _vbuf

	std::shared_ptr< Texture > _glyphTexture;  // Particle texture.

	float _particleSize; // half length of particles' bounding square edge.

	float _particleLifetime; // length of time a particle will live for

	Vector3 _gravity; // direction/force of gravity

	float _restitution; // how much speed is saved on each bounce

	/// Set up space on graphics card
	void initGeometry();




};