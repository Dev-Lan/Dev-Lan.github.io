#pragma once
#include <math.h>
#include <vector>
#include <G3D/G3DAll.h>
#include "ParticleSystem.hpp"

class RingEmitter {
public:
	RingEmitter() {}
	RingEmitter(float radius, float ringWidth, float particlesPerSecond, float maxSpeed, float range = 0.1f) :
		_radius(radius),
		_ringWidth(ringWidth),
		_particlesPerSecond(particlesPerSecond),
		_maxSpeed(maxSpeed),
		_range(range)
		{

		}

	/// This function spawns appropriate particles.
	inline std::vector< Particle > spawnParticles(float dt, const Ray& ray, float ringAngle)
	{
		std::vector< Particle > result;
		float exactNumParticles = _particlesPerSecond * dt;
		int numParticles = floor(exactNumParticles);
		double r = ((double) rand() / (RAND_MAX));
		if (r < exactNumParticles - numParticles) {
			numParticles++;
		}
		for (int i=0; i < numParticles; i++) {
			r = (_ringWidth * _radius) * sqrt( ((double) rand() / (RAND_MAX)) ) + _radius * _ringWidth;
			// double j = r / 2.0;
			double t = ((double) rand() / (RAND_MAX));

			double theta = 2 * M_PI * ((double) rand() / (RAND_MAX));

			// actually just find random speed between maxSpeed / N and maxSpeed
			float speed = ( t * _range + (1.f - _range) )    * _maxSpeed;

			Vector3 pos(r * cos(theta), 0, r * sin(theta));
			Vector3 vel = speed * ray.direction();

			Vector3 axis = Vector3(0,1,0).cross(ray.direction());
			if (!axis.isZero()) { // this will fail if no transformation is necessary, ie direction equals up direction
				float angle = acos( Vector3(0,1,0).dot(ray.direction()) ); // these are already normalized, so you don't need to divide by magnitudes
				Matrix3 rotMat = Matrix3::fromAxisAngle(axis, angle);
				pos = rotMat * pos;
			}
			axis = ray.direction().cross(pos);
			if (!axis.isZero()) {
				Matrix3 rotMat = Matrix3::fromAxisAngle(axis, ringAngle);
				vel = rotMat * vel;
			}
			pos += ray.origin();
			Particle p(pos, vel, Vector2(t, 0));
			result.push_back(p);
		}
		return result;
	}

protected:
	float _radius;
	float _ringWidth;
	float _particlesPerSecond;
	float _maxSpeed;
	float _range;
};