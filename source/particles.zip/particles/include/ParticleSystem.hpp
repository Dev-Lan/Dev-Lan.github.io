#pragma once
#include <G3D/G3DAll.h>

class ParticleSystem {
public:
	/// Every system needs to be able to draw.
	virtual void render3D(RenderDevice* rd) = 0;

	/// Update the particle system by small timestep.
	virtual void update(float dt, const Ray& ray) = 0;
};

class Particle {
public:
	Vector3 pos;
	Vector3 vel;
	Vector3 acc;
	float t;
	Vector2 texCoord; // the width and depth tex coord of the particle.

	Particle(const Vector3& pos, const Vector3& vel, const Vector2& texCoord) :
		pos(pos),
		vel(vel),
		acc(Vector3(0,0,0)),
		t(0),
		texCoord(texCoord)
		{

		}

	/// Do forward Euler integration. You can override in case you don't want to use
	/// a force based approach.
	inline virtual void update(float dt)
	{
		vel += acc * dt;
		pos += vel * dt;
		acc = Vector3(0,0,0);
		t += dt;
	}
};