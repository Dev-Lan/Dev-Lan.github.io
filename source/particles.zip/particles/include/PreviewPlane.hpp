#pragma once
#include <G3D/G3DAll.h>
#include "config.hpp"

class PreviewPlane {
public:
	PreviewPlane()	{	}
	PreviewPlane(
		const std::shared_ptr< Texture >& _tileTexture,
		const std::shared_ptr< Texture >& _tileTextureNRM,
		float width,
		float height,
		float tileWidth,
		float tileLength
				 );

	void render3D(RenderDevice* rd);

	float d_ka;
	float d_kd;
	float d_ks;
	float d_alpha;

protected:
	void initGeometry();
	void initLights();

	std::shared_ptr< Texture > _tileTexture;
	std::shared_ptr< Texture > _tileTextureNRM;

	std::vector< Vector3 > _lightPositions;
	std::vector< Color3 > _lightColors;
	std::vector< float > _lightIntensities;


	float _width;
	float _length;
	float _tileWidth;
	float _tileLength;

	AttributeArray _cornerVerts;
	AttributeArray _cornerTexCoords;
	IndexStream _cornerIndices;
	shared_ptr<VertexBuffer> _vbuf;

};