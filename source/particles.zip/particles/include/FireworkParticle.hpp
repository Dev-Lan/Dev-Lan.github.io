#pragma once
#include "config.hpp"
#include "ParticleSystem.hpp"
#include "MetaEmitter.hpp"

class FireworkParticle : public ParticleSystem {
public:
	FireworkParticle() {	}

	FireworkParticle(
		const std::shared_ptr< Texture >& glyphTexture,
		const std::shared_ptr< Texture >& colorTexture,
		int maxParticles = 6000,
		float emitterRadius = 0.01,
		float particleSize = 0.1f,
		float maxSpeed = 24.f,
		float particleLifetime = 1.f,
		float emitterLifetime = 1.2f,
		float particlesPerSecond = 1000,
		float emittersPerSecond = 2.5f,
		const Vector3& gravity = Vector3(0, -9.8f, 0),
		float restitution = 0.4f,
		float texWidth = 0.1
		) :
			_emitter(emitterRadius, emittersPerSecond, maxSpeed, emitterLifetime),
			_maxParticles(maxParticles),
			_glyphTexture(glyphTexture),
			_colorLookup(colorTexture),
			_particleSize(particleSize),
			_particleLifetime(particleLifetime),
			_gravity(gravity),
			_restitution(restitution),
			_texWidth(texWidth),
			_maxSpeed(maxSpeed)
		{
			initGeometry();
		}



	virtual void render3D(RenderDevice* rd);

	/// Update the particle system by small timestep.
	virtual void update(float dt, const Ray& ray);

protected:
	/// Use parallel lists to avoid a copy when sending info to graphics card.
	Array< Vector3 > _posList;      // positions
	Array< Vector3 > _velList;      // velocities
	Array< float > _tList;          // time alive
	Array< Vector2 > _texCoordList; // color tex coord lookup of width and depth.
	Array< Vector2 > _maskOffsetList;   // This specifies which paint stroke mask to use.


	MetaEmitter _emitter;  // creates new particles

	AttributeArray _posGPU;      // positions on gpu
	AttributeArray _tGPU;        // time on gpu
	AttributeArray _texCoordGPU; // texCoord on gpu
	AttributeArray _maskOffsetGPU; // texCoord on gpu
	IndexStream _indices;
	std::shared_ptr< VertexBuffer > _vbuf;

	int _maxParticles;  // max particles allowed, used to init _vbuf

	std::shared_ptr< Texture > _glyphTexture;  // Particle texture.

	std::shared_ptr< Texture > _colorLookup;   // color / texture of particles

	float _particleSize; // half length of particles' bounding square edge.

	float _particleLifetime; // length of time a particle will live for

	Vector3 _gravity; 

	float _restitution;

	float _texWidth; // percent width of texture used per glyph

	float _maxSpeed;

	/// Set up space on graphics card
	void initGeometry();




};