#pragma once
#include "config.hpp"
#include "ParticleSystem.hpp"
#include "DiscEmitter.hpp"

class FireParticle : public ParticleSystem {
public:
	FireParticle() {	}

	FireParticle(
		const std::shared_ptr< Texture >& glyphTexture,
		const std::shared_ptr< Texture >& colorTexture,
		float width = .8f,
		float height = 1.6f, // regular 1.6
		int maxParticles = 10000,
		float particleSize = 0.012f,
		float particleLifetime = 3.f, // indirectly controls speed of particle // regular 3
		float particlesPerSecond = 3000, // regular 500
		float texWidth = 0.05
		) :
			_emitter(width / 2.f, particlesPerSecond, height / particleLifetime, 0.9f),
			_maxParticles(maxParticles),
			_glyphTexture(glyphTexture),
			_colorLookup(colorTexture),
			_particleSize(particleSize),
			_fireWidth(width),
			_fireHeight(height),
			_particleLifetime(particleLifetime),
			_texWidth(texWidth)
		{
			initGeometry();
		}



	virtual void render3D(RenderDevice* rd);

	/// Update the particle system by small timestep.
	virtual void update(float dt, const Ray& ray);

protected:
	/// Use parallel lists to avoid a copy when sending info to graphics card.
	Array< Vector3 > _posList;      // positions
	Array< Vector3 > _velList;      // velocities
	Array< float > _tList;          // time alive
	Array< Vector2 > _texCoordList; // color tex coord lookup of width and depth. note: height is determined by time
	Array< Vector2 > _maskOffsetList;   // This specifies which paint stroke mask to use.

	DiscEmitter _emitter;  // creates new particles

	AttributeArray _posGPU;      // positions on gpu
	AttributeArray _tGPU;        // time on gpu
	AttributeArray _texCoordGPU; // texCoord on gpu
	AttributeArray _maskOffsetGPU; // texCoord on gpu
	IndexStream _indices;
	std::shared_ptr< VertexBuffer > _vbuf;


	int _maxParticles;  // max particles allowed, used to init _vbuf

	std::shared_ptr< Texture > _glyphTexture;  // masking shape of particles.

	std::shared_ptr< Texture > _colorLookup;   // color / texture of particles

	float _particleSize; // half length of particles' bounding square edge.

	float _fireWidth; // bounding width of particle system

	float _fireHeight; // bounding height of particle height

	float _particleLifetime; // length of time a particle will live for
	
	float _texWidth; // percent width of texture used per glyph

	/// Set up space on graphics card
	void initGeometry();



};