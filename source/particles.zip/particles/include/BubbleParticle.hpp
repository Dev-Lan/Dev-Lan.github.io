#pragma once
#include "config.hpp"
#include "ParticleSystem.hpp"
#include "DiscEmitter.hpp"

class BubbleParticle : public ParticleSystem {
public:
	BubbleParticle() {	}

	BubbleParticle(
		const std::vector< std::shared_ptr< Texture > >& glyphTextures,
		int maxParticles = 1000,
		float emitterRadius = 0.6,
		float particleSize = 0.05f,
		float maxSpeed = .5f,
		float particleLifetime = 4.f,
		float particlesPerSecond = 50,
		float cycleTime = .5f,
		float burstTime = .08f
		) :
			_emitter(emitterRadius, particlesPerSecond, maxSpeed, 0.5f),
			_maxParticles(maxParticles),
			_glyphTextures(glyphTextures),
			_particleSize(particleSize),
			_particleLifetime(particleLifetime),
			_cycleTime(cycleTime),
			_burstTime(burstTime)
		{
			initGeometry();
		}



	virtual void render3D(RenderDevice* rd);

	/// Update the particle system by small timestep.
	virtual void update(float dt, const Ray& ray);

protected:
	/// Use parallel lists to avoid a copy when sending info to graphics card.
	Array< Vector3 > _posList;      // positions
	Array< Vector3 > _velList;      // velocities
	Array< float > _tList;          // time alive
	// Array< Vector2 > _texCoordList; // color tex coord lookup of width and depth.

	DiscEmitter _emitter;  // creates new particles

	AttributeArray _posGPU;      // positions on gpu
	AttributeArray _tGPU;        // time on gpu
	IndexStream _indices;
	std::shared_ptr< VertexBuffer > _vbuf;

	int _maxParticles;  // max particles allowed, used to init _vbuf

	std::vector< std::shared_ptr< Texture > > _glyphTextures;  // Particle texture.

	float _particleSize; // half length of particles' bounding square edge.

	float _particleLifetime; // length of time a particle will live for
	float _cycleTime;
	float _burstTime;

	/// Set up space on graphics card
	void initGeometry();




};