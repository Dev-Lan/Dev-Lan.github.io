#pragma once
#include <math.h>
#include <vector>
#include <G3D/G3DAll.h>
#include "ParticleSystem.hpp"
#include "SphereEmitter.hpp"

/// this emitter emits sphere emitters
class MetaEmitter {
public:
	MetaEmitter() {}
	MetaEmitter(
		float radius, // radius of metaEmitter
		float emittersPerSecond,
		float maxSpeed,
		float emitterLifetime,
		float range = 0.1f, // range in emitter speed
		float emitRadius = 0.1f, // radius of sphereEmitters
		float particlesPerSecond = 200.f, // pps of sphere emitters
		float emitSpeed = .8f, // speed of particles coming off sphereEmitters
		float emitRange = 0.1f // range in particle speed
		) :
			_radius(radius),
			_emittersPerSecond(emittersPerSecond),
			_maxSpeed(maxSpeed),
			_emitterLifetime(emitterLifetime),
			_range(range),
			_emitRadius(emitRadius),
			_particlesPerSecond(particlesPerSecond),
			_emitSpeed(emitSpeed),
			_emitRange(emitRange)
		{

		}
	
	std::vector< Particle > spawnParticles(float dt, const Ray& ray, float maxAngle);


	void updateEmitters(float dt, const Ray& ray, float maxAngle);

	void removeEmitters();

	/// This function spawns appropriate Emitters.
	void spawnEmitters(float dt, const Ray& ray, float maxAngle);

protected:
	float _radius;
	float _emittersPerSecond;
	float _maxSpeed;
	float _emitterLifetime;
	float _range;

	float _emitRadius;
	float _particlesPerSecond;
	float _emitSpeed;
	float _emitRange;

	std::vector< SphereEmitter > _emitters;
	std::vector< float > _time;
	std::vector< int > _explosions;
};