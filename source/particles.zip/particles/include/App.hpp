#pragma once
#include <G3D/G3DAll.h>
#include <iostream>
#include <sstream>
#include "ParticleSystem.hpp"
#include "FireParticle.hpp"
#include "BallParticle.hpp"
#include "WaterParticle.hpp"
#include "EmberParticle.hpp"
#include "FireworkParticle.hpp"
#include "BubbleParticle.hpp"
#include "PreviewPlane.hpp"
#include "AttemptTexture.hpp"


class App : public GApp {
public:
	
	App(const GApp::Settings& settings = GApp::Settings());
	
	virtual void onInit() override;

	virtual void onUserInput(UserInput *ui) override;
	virtual void onSimulation(RealTime rdt, SimTime sdt, SimTime idt) override;

	virtual void onGraphics3D(RenderDevice* rd, Array<shared_ptr<Surface> >& surface3D) override;
	virtual void onGraphics2D(RenderDevice* rd, Array<Surface2D::Ref>& surface2D) override;

protected:
	// ground plane
	std::shared_ptr< PreviewPlane > _previewPlane;
	std::shared_ptr< Texture > _groundTileTexture;
	std::shared_ptr< Texture > _groundTileTextureNRM;

	// particle systems
	std::shared_ptr< Texture > _particleGlyphMaskTexture;
	std::shared_ptr< Texture > _fireColorTexture;
	std::shared_ptr< Texture > _ballTexture;
	std::shared_ptr< Texture > _waterColorTexture;
	std::shared_ptr< Texture > _fireworkColorTexture;

	std::vector< std::shared_ptr< Texture > > _bubbleTextures;

	std::vector< ParticleSystem* > _particleSystems; // list of all particle systems I created
	int _sysIndex; // current particle system to display

	bool _shootingParticles;
	bool _simulating;
	bool _sloMo;
	// TODO FIREFIGHTER MODE

	float _timeElapsed;
	int _framesElapsed;
	float _instantaneousFramerate;



	std::shared_ptr< FirstPersonManipulator > _camManipulator;

};
