#include "BubbleParticle.hpp"

void BubbleParticle::render3D(RenderDevice* rd)
{
	rd->pushState();
	{
		rd->setCullFace(CullFace::NONE);
		Args args;
		// todo multiple textures
		args.setUniform("glyphMask1", _glyphTextures[0], Sampler::video());
		args.setUniform("glyphMask2", _glyphTextures[1], Sampler::video());
		args.setUniform("glyphMask3", _glyphTextures[2], Sampler::video());
		args.setUniform("glyphMask4", _glyphTextures[3], Sampler::video());

		args.setUniform("maxTime", _particleLifetime);
		args.setUniform("cycleTime", _cycleTime);
		args.setUniform("burstTime", _burstTime);

		args.setUniform("particleWidth", _particleSize);

		const CoordinateFrame cframe = rd->cameraToWorldMatrix();
		args.setUniform("camPos", Vector3(cframe.translation.x, cframe.translation.y, cframe.translation.z));


		args.setAttributeArray("vert", _posGPU);
		args.setAttributeArray("time", _tGPU);

		//


		args.setIndexArray(_indices);
		args.setPrimitiveType(PrimitiveType::POINTS);
		LAUNCH_SHADER(BB_TEX_BUBBLE_SHADER, args);
	}
	rd->popState();
}

/// Update the particle system by small timestep.
void BubbleParticle::update(float dt, const Ray& ray)
{
	// Add new particles
	if (_posList.length() < _maxParticles) {
		std::vector< Particle > newParticles = _emitter.spawnParticles(dt, ray);
		for (unsigned int i=0; i < newParticles.size(); i++) {
			if (_posList.length() < _maxParticles) {
				_posList.append(newParticles[i].pos);
				_velList.append(newParticles[i].vel);
				_tList.append(0.f);
			} else {
				break;
			}
		}
	}
	// update physics
	for (int i = 0; i < _posList.length(); i++) {
		// TODO : PERLIN ?
		// _velList[i] += _gravity * dt;
		_posList[i] += _velList[i] * dt;
		_tList[i] += dt;
	}
	// Remove dead particles
	for (int i=0; i < _tList.length(); i++) {
		if (_tList[i] > _particleLifetime) {
			// fastRemove switches the values with the last element of the 
			// array and then removes the last element, so this type of 
			// looping will work.
			_tList.fastRemove(i);
			_posList.fastRemove(i);
			_velList.fastRemove(i);
		}
	}
	// update information on graphics card
	_posGPU.update(_posList);
	_tGPU.update(_tList);
	Array< int > cpuIndices; // TODO : could probably optimize this better.
	cpuIndices.reserve(_maxParticles);
	for (int i=0; i < _maxParticles; i++) {
		if (i < _posList.length()) {
			cpuIndices.append(i);
		} else {
			cpuIndices.append(0);
		}
	}
	_indices.update(cpuIndices);
}


void BubbleParticle::initGeometry()
{
	// intialize data on graphics card to be the right size.
	Array< Vector3 > tmplist;
	tmplist.reserve(_maxParticles);
	for (int i=0; i < _maxParticles; i++) {
		tmplist.append(Vector3(0,0,0));
	}
	Array< float > tmplist1;
	tmplist1.reserve(_maxParticles);
	for (int i=0; i < _maxParticles; i++) {
		tmplist1.append(0.f);
	}
	Array< int > tmplist3;
	tmplist3.reserve(_maxParticles);
	for (int i=0; i < _maxParticles; i++) {
		tmplist3.append(0);
	}

	_vbuf = VertexBuffer::create(_maxParticles * (sizeof(Vector3) + sizeof(int) + sizeof(float)), VertexBuffer::WRITE_EVERY_FRAME);
	_posGPU = AttributeArray(tmplist, _vbuf);
	_tGPU = AttributeArray(tmplist1, _vbuf);
	_indices = IndexStream(tmplist3, _vbuf);
}
