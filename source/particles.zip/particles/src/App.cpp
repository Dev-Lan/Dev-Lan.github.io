#include "App.hpp"

// using namespace std;

App::App(const GApp::Settings& settings) : GApp(settings) {
	renderDevice->setColorClearValue(Color3(0.15, 0.15, 0.15));
}

void App::onInit() {
	GApp::onInit();

	if (DEBUG_ENABLED) {
		std::cout << "debug defined" << std::endl;
		createDeveloperHUD();
		debugWindow->setVisible(false);
		developerWindow->setVisible(false);
		developerWindow->cameraControlWindow->setVisible(false);
		developerWindow->sceneEditorWindow->setVisible(false);
	}
	showRenderingStats = false;
	// ground plane
	_groundTileTexture = AttemptTexture::attemptTextureFromFile(GROUND_TILE_TEXTURE);
	_groundTileTextureNRM = AttemptTexture::attemptTextureFromFile(GROUND_TILE_TEXTURE_NRM);
	_previewPlane = std::shared_ptr< PreviewPlane > (new PreviewPlane(_groundTileTexture, _groundTileTextureNRM, 15, 15, 2, 2));
	
	// camera
	activeCamera()->setPosition(Vector3(0,2,-5));
	activeCamera()->lookAt(Vector3(0,0,0));
	
	// particle systems

	// fire
	_particleGlyphMaskTexture = AttemptTexture::attemptTextureFromFile(GLYPH_MASK);
	_fireColorTexture = AttemptTexture::attemptTextureFromFile(FIRE_COLOR1);
	ParticleSystem* ps = new FireParticle(_particleGlyphMaskTexture, _fireColorTexture);
	_particleSystems.push_back(ps);

	// bouncing balls
	_ballTexture = AttemptTexture::attemptTextureFromFile(BALL_TEXTURE);
	ps = new BallParticle(_ballTexture);
	_particleSystems.push_back(ps);

	// water
	_waterColorTexture = AttemptTexture::attemptTextureFromFile(WATER_COLOR);
	ps = new WaterParticle(_particleGlyphMaskTexture, _waterColorTexture);
	_particleSystems.push_back(ps);

	// ember
	ps = new EmberParticle(_particleGlyphMaskTexture, _fireColorTexture);
	_particleSystems.push_back(ps);

	// firework
	_fireworkColorTexture = AttemptTexture::attemptTextureFromFile(FIREWORK_COLOR);
	ps = new FireworkParticle(_particleGlyphMaskTexture, _fireworkColorTexture);
	_particleSystems.push_back(ps);

	// BUBBLES!!
	// _fireworkColorTexture = AttemptTexture::attemptTextureFromFile(FIREWORK_COLOR);
	std::shared_ptr< Texture > tex = AttemptTexture::attemptTextureFromFile(BUBBLE_TEXTURE1);
	_bubbleTextures.push_back(tex);
	tex = AttemptTexture::attemptTextureFromFile(BUBBLE_TEXTURE2);
	_bubbleTextures.push_back(tex);
	tex = AttemptTexture::attemptTextureFromFile(BUBBLE_TEXTURE3);
	_bubbleTextures.push_back(tex);
	tex = AttemptTexture::attemptTextureFromFile(BUBBLE_TEXTURE4);
	_bubbleTextures.push_back(tex);
	ps = new BubbleParticle(_bubbleTextures);
	_particleSystems.push_back(ps);

	_sysIndex = 0;

	_timeElapsed = 0;
	_framesElapsed = 0;

	_camManipulator = FirstPersonManipulator::create();
	_camManipulator->setMoveRate(1.4f);
	
	setCameraManipulator(_camManipulator);
	addWidget(_camManipulator);
	_simulating = true;


}


void App::onUserInput(UserInput *ui) {
	GApp::onUserInput(ui); // needed for widgets to advance (camera manipulators, GUIs)
	// if (ui->keyDown(GKey::LEFT)) {
	// 	_previewPlane->d_alpha *= .99f;
	// 	std::cout << "ALPHA : " << _previewPlane->d_alpha << std::endl;
	// }
	// if (ui->keyDown(GKey::RIGHT)) {
	// 	_previewPlane->d_alpha *= 1.01f;
	// 	std::cout << "ALPHA : " << _previewPlane->d_alpha << std::endl;
	// }

	if (ui->keyDown(GKey('1'))){
		_sysIndex = 0;
	}
	if (ui->keyDown(GKey('2'))){
		_sysIndex = 1;
	}
	if (ui->keyDown(GKey('3'))){
		_sysIndex = 2;
	}
	if (ui->keyDown(GKey('4'))){
		_sysIndex = 3;
	}
	if (ui->keyDown(GKey('5'))){
		_sysIndex = 4;
	}	
	if (ui->keyDown(GKey('6'))){
		_sysIndex = 5;
	}	

	if (ui->keyPressed(GKey('p'))){
		_simulating = !_simulating;
	}

	if (ui->keyPressed(GKey('o'))){
		_sloMo = !_sloMo;
	}

	// if(ui->keyDown(GKey('a'))){
	// 	_previewPlane->d_kd *= .99f;
	// 	std::cout << "KD : " << _previewPlane->d_kd << std::endl;
	// }
	// if(ui->keyDown(GKey('s'))){
	// 	_previewPlane->d_kd *= 1.01f;
	// 	std::cout << "KD : " << _previewPlane->d_kd << std::endl;
	// }

	// if(ui->keyDown(GKey('z'))){
	// 	_previewPlane->d_ks *= .99f;
	// 	std::cout << "KS : " << _previewPlane->d_ks << std::endl;
	// }
	// if(ui->keyDown(GKey('x'))){
	// 	_previewPlane->d_ks *= 1.01f;
	// 	std::cout << "KS : " << _previewPlane->d_ks << std::endl;
	// }

// if (ui->keyDown(GKey::LEFT_MOUSE)) {
// }
// }

	if (ui->keyDown(GKey(' '))) {
		_shootingParticles = true;
	} else {
		_shootingParticles = false;
	}

}


void App::onSimulation(RealTime rdt, SimTime sdt, SimTime idt) {
	GApp::onSimulation(rdt, sdt, idt); // need for widgets to advance (camera manipulators, GUIs)
	/// rdt is the amount of real time that has passed in seconds since last call to onSimulation
	_framesElapsed++;
	_timeElapsed += rdt;
	if (_framesElapsed % 10 == 0) {
		_instantaneousFramerate = 1.f / rdt;
	}

	if (_simulating) {
		if (_sloMo) {
			rdt *= 0.1f;
		}
		if (_shootingParticles) {
			// activeCamera()->frame().lookVector();
			// activeCamera()->frame().translation;
			Point3 origin = activeCamera()->frame().translation;
			Vector3 direction = activeCamera()->frame().lookVector();
			_particleSystems[_sysIndex]->update(rdt, Ray(origin, direction));
		} else {
			_particleSystems[_sysIndex]->update(rdt, Ray(Point3(0,0.1,0), Vector3(0,1,0)));
		}
	}
}



void App::onGraphics3D(RenderDevice* rd, Array<shared_ptr<Surface> >& surface3D) {
	swapBuffers();
	rd->clear();
	_previewPlane->render3D(rd);
	_particleSystems[_sysIndex]->render3D(rd);
}


void App::onGraphics2D(RenderDevice* rd, Array<Surface2D::Ref>& posed2D) {
	Surface2D::sortAndRender(rd, posed2D);
	std::string fps = std::to_string(_instantaneousFramerate);
	fps = fps.substr(0, 5);

	debugFont->draw2D(rd, fps.c_str(), Point2(0,0), 48, Color3::white());
	fps = std::to_string(_framesElapsed / _timeElapsed);
	fps = fps.substr(0, 5);
	debugFont->draw2D(rd, fps.c_str(), Point2(0,50), 48, Color3::white());

// Array<Vector2> circle;
// int numberOfVerts = 20;
// Vector2 center(500,150);
// double tau = 6.28;
// double radius = 100;
// for(int i=0; i<numberOfVerts; ++i){
// double percent = (double) i / (double) numberOfVerts;
// double x = radius*sin(percent*tau) + center.x;
// double y = radius*cos(percent*tau) + center.y;
// circle.append(Vector2(x,y));
// }
// Draw::poly2D(circle, rd, Color3::blue());
}
