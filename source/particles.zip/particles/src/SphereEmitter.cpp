#include "SphereEmitter.hpp"

void SphereEmitter::updatePosition(float dt)
{
	_vel = _vel + _gravity * dt;
	_pos = _pos + _vel * dt;
	// std::cout << "pos : (" << _pos << ")  :  vel : (" << _vel << ")" << std::endl;
	// std::cout << "gravity : " << _gravity << std::endl;
}

/// This function spawns appropriate particles.
std::vector< Particle > SphereEmitter::spawnParticles(float dt)
{
	std::vector< Particle > result;
	float exactNumParticles = _particlesPerSecond * dt;
	int numParticles = floor(exactNumParticles);
	double r = ((double) rand() / (RAND_MAX));
	if (r < exactNumParticles - numParticles) {
		numParticles++;
	}

	for (int i=0; i < numParticles; i++) {
		// using a sphere point picking described here
		// http://mathworld.wolfram.com/SpherePointPicking.html
		double x1, x2, x1_sq, x2_sq;
		do {
			x1 =  ((double) rand() / (RAND_MAX));
			x1 = 2 * x1 - 1;
			x2 =  ((double) rand() / (RAND_MAX));
			x2 = 2 * x2 - 1;
			x1_sq = x1 * x1;
			x2_sq = x2 * x2;
		} while (x1_sq + x2_sq >=1);

		double x = 2 * x1 * sqrt(1 - x1_sq - x2_sq);
		double y = 2 * x2 * sqrt(1 - x1_sq - x2_sq);
		double z = 1 - 2 * (x1_sq + x2_sq);
		Vector3 v(x,y,z);
		Vector3 pos = _pos + _radius * v;
		Vector3 vel = 0.2f * _vel + _emitSpeed * v;

		Particle p(pos, vel, Vector2(0, 0));
		result.push_back(p);
	}
	return result;
}
