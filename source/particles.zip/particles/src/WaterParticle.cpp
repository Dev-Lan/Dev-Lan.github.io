#include "WaterParticle.hpp"

void WaterParticle::render3D(RenderDevice* rd)
{
	rd->pushState();
	{
		rd->setCullFace(CullFace::NONE);
		Args args;
		args.setUniform("glyphMask", _glyphTexture, Sampler::video());
		args.setUniform("fireTexture", _colorLookup, Sampler::video());

		args.setUniform("particleWidth", _particleSize);
		args.setUniform("maxTime", _particleLifetime);
		args.setUniform("texWidth", _texWidth);
		
		const CoordinateFrame cframe = rd->cameraToWorldMatrix();
		args.setUniform("camPos", Vector3(cframe.translation.x, cframe.translation.y, cframe.translation.z));
		args.setUniform("maskTexChunkPercent", Vector2(0.25f, 0.25f)); // yay for hardcoding

		args.setAttributeArray("vert", _posGPU);
		args.setAttributeArray("t", _tGPU);
		args.setAttributeArray("tCoord", _texCoordGPU);
		args.setAttributeArray("maskTexIndex", _maskOffsetGPU);
		args.setIndexArray(_indices);
		args.setPrimitiveType(PrimitiveType::POINTS);
		LAUNCH_SHADER(BB_TEX_SHADER, args);
	}
	rd->popState();
}

/// Update the particle system by small timestep.
void WaterParticle::update(float dt, const Ray& ray)
{
	bool mustUpdateTexCoordList = false;
	// Add new particles
	if (_posList.length() < _maxParticles) {
		std::vector< Particle > newParticles = _emitterCenter.spawnParticles(dt, ray);
		// add central stream
		for (unsigned int i=0; i < newParticles.size(); i++) {
			if (_posList.length() < _maxParticles) {
				_posList.append(newParticles[i].pos);
				_velList.append(newParticles[i].vel);
				_tList.append(0.f);
				_texCoordList.append(newParticles[i].texCoord);
				mustUpdateTexCoordList = true;
			} else {
				break;
			}
		}
		// add edge stream
		std::vector< Particle > newEdgeParticles = _emitterEdge.spawnParticles(dt, ray, 3.14 / 8.f);
		for (unsigned int i=0; i < newEdgeParticles.size(); i++) {
			if (_posList.length() < _maxParticles) {
				_posList.append(newEdgeParticles[i].pos);
				_velList.append(newEdgeParticles[i].vel);
				_tList.append(0.f);
				_texCoordList.append(newEdgeParticles[i].texCoord);
				mustUpdateTexCoordList = true;
			} else {
				break;
			}
		}
	}
	for (int i = 0; i < _posList.length(); i++) {
		_velList[i] += _gravity * dt;
		_posList[i] += _velList[i] * dt;
		if (_posList[i].y - _particleSize <= 0) {
			_posList[i].y = _particleSize;
			// TODO : flip around normal
			_velList[i].y *= -1;
			// I want restitution on whole vector, not just up, to fake lateral friction.
			_velList[i] *= _restitution;
		}
		_tList[i] += dt;
	}
	// Remove dead particles
	for (int i=0; i < _tList.length(); i++) {
		if (_tList[i] > _particleLifetime) {
			_tList.fastRemove(i);
			_posList.fastRemove(i);
			_velList.fastRemove(i);
			_texCoordList.fastRemove(i);
			mustUpdateTexCoordList = true;		}
	}
	// update information on graphics card
	_posGPU.update(_posList);
	_tGPU.update(_tList);
	Array< int > cpuIndices; // TODO : could probably optimize this better.
	cpuIndices.reserve(_maxParticles);
	for (int i=0; i < _maxParticles; i++) {
		if (i < _posList.length()) {
			cpuIndices.append(i);
		} else {
			cpuIndices.append(0);
		}
	}
	_indices.update(cpuIndices);
	if (mustUpdateTexCoordList) {
		_texCoordGPU.update(_texCoordList);
	}
}


void WaterParticle::initGeometry()
{
	// intialize data on graphics card to be the right size.
	Array< Vector3 > tmplist;
	tmplist.reserve(_maxParticles);
	for (int i=0; i < _maxParticles; i++) {
		tmplist.append(Vector3(0,0,0));
	}
	Array< float > tmplist2;
	tmplist2.reserve(_maxParticles);
	for (int i=0; i < _maxParticles; i++) {
		tmplist2.append(0);
	}
	Array< int > tmplist3;
	tmplist3.reserve(_maxParticles);
	for (int i=0; i < _maxParticles; i++) {
		tmplist3.append(0);
	}
	Array< Vector2 > tmplist4;
	tmplist.reserve(_maxParticles);
	for (int i=0; i < _maxParticles; i++) {
		tmplist4.append(Vector2(0,0));
	}

	// preload all of the mask offsets, since they don't ever need to change.
	_maskOffsetList.reserve(_maxParticles);
	for (int i=0; i < _maxParticles; i++) {
		int r1 = 4 * ((double) rand() / (RAND_MAX));
		int r2 = 4 * ((double) rand() / (RAND_MAX));
		_maskOffsetList.append(Vector2(r1, r2));
		// std::cout << "(" << r1 << "," << r2 << ")" << std::endl;
	}

	_vbuf = VertexBuffer::create(_maxParticles * (sizeof(Vector3) + sizeof(Vector2) + sizeof(Vector2) + sizeof(float) + sizeof(int)), VertexBuffer::WRITE_EVERY_FRAME);
	_posGPU = AttributeArray(tmplist, _vbuf);
	_tGPU = AttributeArray(tmplist2, _vbuf);
	_indices = IndexStream(tmplist3, _vbuf);
	_texCoordGPU = AttributeArray(tmplist4, _vbuf);
	_maskOffsetGPU = AttributeArray(_maskOffsetList, _vbuf);
}
