#include "MetaEmitter.hpp"

std::vector< Particle > MetaEmitter::spawnParticles(float dt, const Ray& ray, float maxAngle)
{
	std::vector< Particle > result;
	for (unsigned int i=0; i < _emitters.size(); i++) {
		std::vector< Particle > tmp = _emitters[i].spawnParticles(dt);
		// concise append code courtesy of http://stackoverflow.com/questions/2551775/c-appending-a-vector-to-a-vector
		result.insert(result.end(), tmp.begin(), tmp.end());
	}
	return result;
}


void MetaEmitter::updateEmitters(float dt, const Ray& ray, float maxAngle)
{

	spawnEmitters(dt, ray, maxAngle);
	// update positions
	for (unsigned int i=0; i < _emitters.size(); i++) {
		_time[i] += dt;
		_emitters[i].updatePosition(dt);
	}
	removeEmitters();
}

void MetaEmitter::removeEmitters()
{
	for (unsigned int i=0; i < _emitters.size(); i++) {
		if (_time[i] > _emitterLifetime) {
			if (_explosions[i] > 0) {
				std::swap(_emitters[i], _emitters.back());
				_emitters.pop_back();
				std::swap(_time[i], _time.back());
				_time.pop_back();
				std::swap(_explosions[i], _explosions.back());
				_explosions.pop_back();
			} else {
				_time[i] = _emitterLifetime * 0.9f;
				_explosions[i]++;
				_emitters[i].setEmitSpeed(_emitSpeed * 5);
				_emitters[i].setParticlesPerSecond(_particlesPerSecond * 10);
			}
		}
	}
}

/// This function spawns appropriate Emitters.
void MetaEmitter::spawnEmitters(float dt, const Ray& ray, float maxAngle)
{
	float exactNumEmitters = _emittersPerSecond * dt;
	int numEmitters = floor(exactNumEmitters);
	double r = ((double) rand() / (RAND_MAX));
	if (r < exactNumEmitters - numEmitters) {
		numEmitters++;
	}
	for (int i=0; i < numEmitters; i++) {
		r = _radius * sqrt( ((double) rand() / (RAND_MAX)) );
		double t = ((double) rand() / (RAND_MAX));
		double theta = 2 * M_PI * ((double) rand() / (RAND_MAX));

		float speed = ( t * _range + (1.f - _range) ) * _maxSpeed;

		Vector3 pos(r * cos(theta), 0, r * sin(theta));
		Vector3 vel = speed * ray.direction();

		Vector3 axis = Vector3(0,1,0).cross(ray.direction());
		if (!axis.isZero()) { // this will fail if no transformation is necessary, ie direction equals up direction
			float angle = acos( Vector3(0,1,0).dot(ray.direction()) ); // these are already normalized, so you don't need to divide by magnitudes
			Matrix3 rotMat = Matrix3::fromAxisAngle(axis, angle);
			pos = rotMat * pos;
		}
		axis = ray.direction().cross(pos);
		if (!axis.isZero()) {
			r = ((double) rand() / (RAND_MAX));
			r = 2 * r - 1; // randome between [-1, 1]
			Matrix3 rotMat = Matrix3::fromAxisAngle(axis, r * maxAngle);
			vel = rotMat * vel;
		}
		pos += ray.origin();
		SphereEmitter newEmitter(_emitRadius, _particlesPerSecond, _emitSpeed, pos, vel);
		_emitters.push_back(newEmitter);
		_time.push_back(0.f);
		_explosions.push_back(0);
	}
}
