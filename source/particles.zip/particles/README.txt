##########################################################################################
# Name:                            Devin Lange                                           #
##########################################################################################
# Email Adress:                    lange604@umn.edu                                      #
##########################################################################################

To compile this code you need to download and install G3D-10:(http://g3d.sourceforge.net/)

Then you simply need to run iCompile in the same directory as this README.txt file. If you
just want to run the application an executable for mac computers can be found here.

http://dev-lan.github.io/classes/5611csci-hw1.html