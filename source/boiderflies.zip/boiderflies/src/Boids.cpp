#include "Boids.hpp"


/// add boids with your emitter
void Boids::addBoids(float dt, const Ray& ray)
{
	if (_positions.length() < _maxBoids) {
		std::vector< Particle > newParticles = _emitter.spawnParticles(dt, ray);
		for (unsigned int i=0; i < newParticles.size(); i++) {
			if (_positions.length() < _maxBoids) {
				_positions.append(newParticles[i].pos);
				_velocities.append(newParticles[i].vel);
				_accelerations.append(Vector3(0,0,0));
				const float closeEnough = _boundingRadius * 10;
				GraphNode* closestNode = _prm->getCloseEnoughNode(Convert::to2D(newParticles[i].pos), closeEnough, _boundingRadius);
				_goals.append(closestNode);
				_cycle.append(0);
			} else {
				break; // We're at maximum capacity cap'n
			}
		}
	}
}

/// run one simulation step
void Boids::doStep(float dt)
{
	assert(_positions.length() == _velocities.length() && _velocities.length() == _accelerations.length() && _accelerations.length() == _cycle.length());
	// todo : initialize spatial data structure here
	for (int i=0; i < _positions.size(); i++) {
		toGoal(i);
		Array< int > neighbors = findNeighbors(i);
		if (neighbors.length() > 0) {
			seperate(neighbors, i);
			align(neighbors, i);
			addCohesion(neighbors, i);
		}
		avoidObstacles(i);
	}
	doEulerStep(dt);
	updateGraphicsCard();
}

/// push new positions headings, etc
void Boids::updateGraphicsCard()
{
	_posGPU.update(_positions);
	_headingGPU.update(_velocities); // doesn't have to be this exactly.
	_cycleGPU.update(_cycle);  // todo
	Array< int > cpuIndices; // TODO : could probably optimize this better.
	cpuIndices.reserve(_maxBoids);
	for (int i=0; i < _maxBoids; i++) {
		if (i < _positions.length()) {
			cpuIndices.append(i);
		} else {
			cpuIndices.append(0);
		}
	}
	_indices.update(cpuIndices);
}

/// render the boids
void Boids::render3D(RenderDevice* rd)
{
	rd->pushState();
	{
		rd->setCullFace(CullFace::NONE);
		Args args;
		// args.setUniform("glyphMask", _glyphTexture, Sampler::video());

		args.setUniform("particleWidth", _boundingRadius);

		const CoordinateFrame cframe = rd->cameraToWorldMatrix();
		// args.setUniform("camPos", Vector3(cframe.translation.x, cframe.translation.y, cframe.translation.z));
		args.setUniform("wingSpan", 2*_boundingRadius);
		args.setUniform("wingLength", .75f * 2 * _boundingRadius);
		args.setUniform("tex", _texture, Sampler::video());

		args.setAttributeArray("vert", _posGPU);
		args.setAttributeArray("dir", _headingGPU);
		args.setAttributeArray("t", _cycleGPU);
		args.setIndexArray(_indices);
		args.setPrimitiveType(PrimitiveType::POINTS);
		LAUNCH_SHADER(BUTTEFLY_SHADER, args);
		// LAUNCH_SHADER(BASIC_PARTICLE, args);
	}
	rd->popState();
}

// /// all boids move towards this goal
// Vector3 currentGoal;


/// adds goal force to _accelerations
void Boids::toGoal(int index)
{
	assert(_positions.length() == _velocities.length() && _velocities.length() == _accelerations.length() && _accelerations.length() == _goals.length());
	assert(index < _positions.length());
	// todo : double check this is visible?
		// find a new node if lost
	// I don't do this, it is technically possible to get lost
	Vector3 currentGoal = Convert::to3D(_goals[index]->pos) + Vector3(0, goalHeight, 0); // could have fraction of goal height, for linear path to goal, but I think this will look cool anyway
	std::cout << currentGoal;
	Vector3 goalDir = (currentGoal - _positions[index]).direction();
	// Vector3 toGoalForce = (goalDir * _maxSpeed) - _velocities[index];
	const float scaler = 5.f;
	_accelerations[index] += scaler * goalDir;
	// advance current goal
	if (_scene->collisionFreeDisc(_goals[index]->toGoal->pos, Convert::to2D(_positions[index]), _boundingRadius)) {
		_goals[index] = _goals[index]->toGoal; // if goal is already at the final node, toGoal will just point to itself
	}

}


/// repulses ground and columns
void Boids::avoidObstacles(int index)
{
	/// columns
	// TODO, play with this.
	const float largeForce = 1000;
	for (unsigned int j=0; j < _scene->_discs.size(); j++) {
		Vector2 fromWall = Convert::to2D(_positions[index]) - _scene->_discs[j].pos;
		Vector2 fromWallDir = fromWall.directionOrZero();
		float magnitude;
		float dSquared = fromWall.dot(fromWall);
		float rSquared = _scene->_discs[index].radius * _scene->_discs[index].radius;
		if (dSquared <=  rSquared) {
			magnitude = largeForce;
		} else {
			magnitude = largeForce /  (pow( (dSquared - rSquared), 4) + 1);
		}
		// assert(magnitude <= largeForce);
		// std::cout << dSquared << std::endl;
		// Vector3 obstForce = Convert::to3D(magnitude * fromWallDir);
		// assert(!isnan(obstForce.x));
		// if (isnan(obstForce.x)) {
		// 	std::cout << obstForce <<std::endl;
		// }
		_accelerations[index] += Convert::to3D(magnitude * fromWallDir);
	}
	/// ground
	if (_positions[index].y < 2) {
		// const float scaler = 1.f;
		float d = _positions[index].y - 2;
		_accelerations[index].y += pow(d, 6); // make sure you have even exponent
	}

}

/// adds separation force to _accelerations
void Boids::seperate(const Array< int >& neighbors, int index)
{
	assert(_positions.length() == _velocities.length() && _velocities.length() == _accelerations.length());
	assert(index < _positions.length());
	Vector3 F(0,0,0);
	for (int i=0; i < neighbors.length(); i++) {
		Vector3 v = _positions[index] - _positions[ neighbors[i] ];
		v = v / (v.dot(v));
		F += v;
	}
	const float separateScalar = 1.5f;
	_accelerations[index] += separateScalar * F;
}

/// adds alignment force to _accelerations
void Boids::align(const Array< int >& neighbors, int index)
{
	assert(_positions.length() == _velocities.length() && _velocities.length() == _accelerations.length());
	assert(index < _positions.length());
	Vector3 averageV(0,0,0);
	for (int i=0; i < neighbors.length(); i++) {
		averageV += _velocities[ neighbors[i] ];
	}
	averageV /= (float) neighbors.length();
	_accelerations[index] += averageV - _velocities[index]; // maybe need a scaling factor for this force
}

/// adds cohesion force to _accelerations
void Boids::addCohesion(const Array< int >& neighbors, int index)
{
	assert(_positions.length() == _velocities.length() && _velocities.length() == _accelerations.length());
	assert(index < _positions.length());
	Vector3 averageP(0,0,0);
	for (int i=0; i < neighbors.length(); i++) {
		averageP += _positions[ neighbors[i] ];
	}
	averageP /= (float) neighbors.length();
	Vector3 toP = averageP - _positions[index];
	_accelerations[index] += toP; // todo : maybe need a scaling factor here too.
}

void Boids::doEulerStep(float dt)
{
	assert(_positions.length() == _velocities.length() && _velocities.length() == _accelerations.length());
	for (int i=0; i < _positions.length(); i++) {
		if (_accelerations[i].dot(_accelerations[i]) > _maxAccel * _maxAccel) {
			_accelerations[i] = _accelerations[i].direction() * _maxAccel;
		}
		_velocities[i] += _accelerations[i] * dt;
		_accelerations[i] = Vector3(0,0,0); // clear this since I'm here already.
		if (_velocities[i].dot(_velocities[i]) > _maxSpeed * _maxSpeed) {
			_velocities[i] = _velocities[i].direction() * _maxSpeed;
		}
		_positions[i] += _velocities[i] * dt;
		_cycle[i] += dt;
	}
}

Array< int > Boids::findNeighbors(int index)
{
	// do the slow neighbor search for now...
	assert(_positions.length() == _velocities.length() && _velocities.length() == _accelerations.length());
	assert(index < _positions.length());
	Array< int > neighborIndices;
	for (int i=0; i < _positions.size(); i++) {
		if (index != i) {
			Vector3 v = _positions[index] - _positions[i];
			if (v.dot(v) < _neighborDistSquared) {
				neighborIndices.append(i);
			}
		}
	}
	return neighborIndices;
}

void Boids::initGraphics()
{
	Array< Vector3 > tmplist;
	tmplist.reserve(_maxBoids);
	for (int i=0; i < _maxBoids; i++) {
		tmplist.append(Vector3(0,0,0));
	}
	Array< Vector3 > tmplist2;
	tmplist2.reserve(_maxBoids);
	for (int i=0; i < _maxBoids; i++) {
		tmplist2.append(Vector3(0,0,0));
	}
	Array< float > tmplist3;
	tmplist3.reserve(_maxBoids);
	for (int i=0; i < _maxBoids; i++) {
		tmplist3.append(0);
	}
	Array< int > tmplist4;
	tmplist4.reserve(_maxBoids);
	for (int i=0; i < _maxBoids; i++) {
		tmplist4.append(0);
	}	
	_vbuf = VertexBuffer::create(_maxBoids * 
									(
									sizeof(Vector3) + 
									sizeof(Vector3) + 
									sizeof(float) +
									sizeof(int)
									), VertexBuffer::WRITE_EVERY_FRAME);
	_posGPU = AttributeArray(tmplist, _vbuf);
	_headingGPU = AttributeArray(tmplist2, _vbuf);
	_cycleGPU = AttributeArray(tmplist3, _vbuf);
	_indices = IndexStream(tmplist4, _vbuf);
}