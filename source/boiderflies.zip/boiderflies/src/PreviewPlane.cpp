#include "PreviewPlane.hpp"

PreviewPlane::PreviewPlane(
	const std::shared_ptr< Texture >& tileTexture,
	const std::shared_ptr< Texture >& tileTextureNRM,
	float width,
	float length,
	float tileWidth,
	float tileLength
	) : 
	_tileTexture(tileTexture),
	_tileTextureNRM(tileTextureNRM),
	_width(width),
	_length(length),
	_tileWidth(tileWidth),
	_tileLength(tileLength)
{
	initGeometry();
	initLights();
	d_ka = 0.05f;
	d_kd = 0.75f;
	d_ks = 0.20f;
	d_alpha = 240.f;
}

void PreviewPlane::render3D(RenderDevice* rd) {
	// const G3D::String shaderPattern = SHADER_DIR + "textured.*";
	rd->pushState();
	{
		rd->setCullFace(CullFace::NONE);
		Args args;
		args.setUniform("tex", _tileTexture, Sampler::video());
		args.setUniform("texNRM", _tileTextureNRM, Sampler::video());
		// TODO :: find nice values for wood.
		args.setUniform("K_A", Color3(d_ka, d_ka, d_ka));
		args.setUniform("K_D", Color3(d_kd, d_kd, d_kd));
		args.setUniform("K_S", Color3(d_ks, d_ks, d_ks));
		args.setUniform("alpha", d_alpha);

		args.setMacro("NUM_POINT_LIGHTS", (int)_lightPositions.size());
		for (unsigned int i=0; i < _lightPositions.size(); i++) {
			args.setArrayUniform("pointLights", i, _lightPositions[i]);
			args.setArrayUniform("pointLightColors", i, _lightColors[i]);
			args.setArrayUniform("pointLightIntensities", i, _lightIntensities[i]);

		}
		Point3 camPosition = rd->cameraToWorldMatrix().translation;
		args.setUniform("camPos", camPosition);

		args.setAttributeArray("vert", _cornerVerts);
		args.setAttributeArray("texCoord", _cornerTexCoords);
		args.setIndexArray(_cornerIndices);
		args.setPrimitiveType(PrimitiveType::TRIANGLE_STRIP);
		LAUNCH_SHADER(LIT_TEX_NRM, args);
	}
	rd->popState();
}

void PreviewPlane::initGeometry() {
	Array< Vector3 > cpuVerts;
	Array< Vector2 > cpuTexCoords;
	Array< int > cpuIndices;
	float halfWidth = _width / 2.f;
	float halfLength = _length / 2.f;
	const float y = 0;
	float tileCountWidth  = _width  / _tileWidth;
	float tileCountLength = _length / _tileLength;

	Vector3 v1, v2, v3, v4;
	v1 = Vector3(-halfWidth, y,  halfLength);
	v2 = Vector3( halfWidth, y,  halfLength);
	v3 = Vector3(-halfWidth, y, -halfLength);
	v4 = Vector3( halfWidth, y, -halfLength);
	cpuVerts.append(v1, v2, v3, v4);

	Vector2 t1, t2, t3, t4;
	t1 = Vector2(0,tileCountLength);
	t2 = Vector2(tileCountWidth,tileCountLength);
	t3 = Vector2(0,0);
	t4 = Vector2(tileCountWidth,0);


	cpuTexCoords.append(t1, t2, t3, t4);
	cpuIndices.append(0,1,2,3);

	_vbuf = VertexBuffer::create(
		sizeof(Vector3) * cpuVerts.length() + 
		sizeof(Vector2) * cpuTexCoords.length() + 
		sizeof(int) * cpuIndices.length()
	);
	_cornerVerts = AttributeArray(cpuVerts, _vbuf);
	_cornerTexCoords = AttributeArray(cpuTexCoords, _vbuf);
	_cornerIndices = IndexStream(cpuIndices, _vbuf);
}

void PreviewPlane::initLights() {
	_lightPositions.push_back(Vector3(2.4,7,0));
	_lightColors.push_back(Color3(1.f, 1.f, 1.f));
	_lightIntensities.push_back(2.50f);

	_lightPositions.push_back(Vector3(-2.4,7,1.6));
	_lightColors.push_back(Color3(1.f, 1.f, 1.f));
	_lightIntensities.push_back(2.50f);

	_lightPositions.push_back(Vector3(-2.4,7,-2.6));
	_lightColors.push_back(Color3(1.f, 1.f, 1.f));
	_lightIntensities.push_back(2.5f);

	// _lightPositions.push_back(Vector3(0,1,0));
	// _lightColors.push_back(Color3(.6f, .1f, .18f));
	// _lightIntensities.push_back(1.f);
}
