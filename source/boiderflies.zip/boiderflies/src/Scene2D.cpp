#include "Scene2D.hpp"

Scene2D::Scene2D(
	const std::vector< Vector2 >& pos,
	const std::vector< float >& radius,
	const Vector2& topRight,
	const Vector2& botLeft
	) :
		topRight(topRight),
		botLeft(botLeft),
		_cylRenderer()
{
	assert(pos.size() == radius.size());
	for (unsigned int i=0; i < pos.size(); i++) {
		disc d;
		d.pos = pos[i];
		d.radius = radius[i];
		_discs.push_back(d);
	}
}

bool Scene2D::collisionFreeDisc(const Vector2& A, const Vector2& B, float R) const
{
	// http://math.stackexchange.com/questions/311921/get-location-of-vector-circle-intersection
	// make a ray from point A to point B with direction dir.
	Vector2 dir = B - A;
	for (unsigned int i=0; i < _discs.size(); i++) {
		// check for collision
		Vector2 v = A - _discs[i].pos;
		float a = dir.dot(dir);
		float b = 2 * dir.dot(v);
		float c = v.dot(v) - (_discs[i].radius + R) * (_discs[i].radius + R);
		float discrm = b*b - 4*a*c;
		if (discrm > 0) {
			float t1 = (-b + sqrt(discrm)) / (2.0f * a);
			float t2 = (-b - sqrt(discrm)) / (2.0f * a);
			if ( (t1 >= 0.f && t1 <= 1.f) || (t2 >= 0.f && t2 <= 1.f) ) {
				// there IS a collision with this disc.
				return false;
			}
		}
		// otherwise check other discs for collision
	}
	// todo : if lines are added check for them too.

	// no collision was found.
	return true;
}

bool Scene2D::collisionFreeDisc(const Vector2& A, const Vector2& B, float R, int sphereIndex) const
{
		// http://math.stackexchange.com/questions/311921/get-location-of-vector-circle-intersection
	// make a ray from point A to point B with direction dir.
	Vector2 dir = B - A;
	int i = sphereIndex;
	// check for collision
	Vector2 v = A - _discs[i].pos;
	float a = dir.dot(dir);
	float b = 2 * dir.dot(v);
	float c = v.dot(v) - (_discs[i].radius + R) * (_discs[i].radius + R);
	float discrm = b*b - 4*a*c;
	if (discrm > 0) {
		float t1 = (-b + sqrt(discrm)) / (2.0f * a);
		float t2 = (-b - sqrt(discrm)) / (2.0f * a);
		if ( (t1 >= 0.f && t1 <= 1.f) || (t2 >= 0.f && t2 <= 1.f) ) {
			// there IS a collision with this disc.
			return false;
		}
	}

	// no collision was found.
	return true;
}


bool Scene2D::collisionFreeDisc(const Vector2& p, float r) const
{
	for (unsigned int i=0; i < _discs.size(); i++) {
		float r2 = (r + _discs[i].radius) * (r + _discs[i].radius);
		Vector2 v = p - _discs[i].pos;
		if (v.dot(v) < r2) {
			return false;
		}
	}
	return true;
}


void Scene2D::render3D(RenderDevice* rd) const
{
	// TODO, render cylinders instead of spheres, (high priority)
	for (unsigned int i=0; i < _discs.size(); i++) {
		Vector3 bot = Convert::to3D(_discs[i].pos);
		_cylRenderer.render3D(rd, bot, 10, _discs[i].radius); // todo don't hardcode you lazy bum
		// // Sphere s(Convert::to3D(_discs[i].pos), _discs[i].radius);
		// // Draw::sphere(s, rd, Color4(.8, .1, .13, 0.5f), Color3(0,0,0));
		// Vector3 top = bot + Vector3(0, 10, 0);
		// Sphere s(bot, _discs[i].radius);
		// Draw::sphere(s, rd, Color4(.8, .1, .13, 0.5f), Color3(0,0,0));
		// Sphere s2(top, _discs[i].radius);
		// Draw::sphere(s2, rd, Color4(.8, .1, .13, 0.5f), Color3(0,0,0));

		// Capsule c(bot, top, _discs[i].radius);
		// Draw::capsule(c, rd, Color4(.8, .1, .13, 0.5f), Color3(0,0,0));
	}
}

void Scene2D::addSphere(const Vector2& p, float r)
{
	disc d;
	d.pos = p;
	d.radius = r;
	_discs.push_back(d);
}






