#include "App.hpp"

// using namespace std;

App::App(const GApp::Settings& settings) : GApp(settings) {
	renderDevice->setColorClearValue(Color3(0.15, 0.15, 0.15));
}

void App::onInit() {
	GApp::onInit();

	if (DEBUG_ENABLED) {
		std::cout << "debug defined" << std::endl;
		createDeveloperHUD();
		debugWindow->setVisible(false);
		developerWindow->setVisible(false);
		developerWindow->cameraControlWindow->setVisible(false);
		developerWindow->sceneEditorWindow->setVisible(false);
	}
	showRenderingStats = false;
	_groundTileTexture = AttemptTexture::attemptTextureFromFile(GROUND_TILE_TEXTURE);
	_groundTileTextureNRM = AttemptTexture::attemptTextureFromFile(GROUND_TILE_TEXTURE_NRM);
	_previewPlane = std::shared_ptr< PreviewPlane > (new PreviewPlane(_groundTileTexture, _groundTileTextureNRM, 20, 20, 2, 2));
	
	// camera
	activeCamera()->setPosition(Vector3(-5,5,-5));
	activeCamera()->lookAt(Vector3(0,5,0));
	
	_viewRoadMap = false;
	_viewPath = false;
	// init scene
	std::vector< Vector2 > obstPos;
	obstPos.push_back(Vector2(0,0));

	std::vector< float > obstR;
	obstR.push_back(2.f);
	Vector2 tr(10,10);
	Vector2 bl(-10, -10);
	std::cout << "initializing scene..." << std::endl;
	_scene = std::shared_ptr< Scene2D > (new Scene2D(obstPos, obstR, tr, bl));
	std::cout << "initializing road map..." << std::endl;
	_agentRadius = .16f;
	_prm = std::shared_ptr< PRM > (new PRM(_scene, 100, 4, _agentRadius));
	std::cout << "roadmap complete." << std::endl;
	std::cout << "beginning search for path" << std::endl;
	// _startPos = Vector2(-9,-9);
	// _agentPos = _startPos;
	// _goalPos = Vector2(9,9);
	// _currentPath = _prm->getPath(_startPos, _goalPos);
	_maxHeight = 12.f;
	_goalPos = Vector3(7,7,7);
	_goalNode = _prm->addNode(Convert::to2D(_goalPos));
	_prm->fromGoalSearch(_goalNode);
	std::cout << "path initialized" << std::endl;

	// init boids
	_butterflyTexture = AttemptTexture::attemptTextureFromFile(BUTTERFLY_TEXTURE);
	const int maxParticles = 1000;
	const float maxSpeed = 5.f;
	const float maxAccel = 10.f;
	const float neighborDist = 0.5f;
	const float emitterRadius = 0.2f;
	const float particlesPerSecond = 50.f;
	_boids = std::shared_ptr< Boids > (new Boids(
			_scene,
			_prm,
			_butterflyTexture,
			maxParticles,
			maxSpeed,
			maxAccel,
			neighborDist,
			_agentRadius, 
			emitterRadius,
			particlesPerSecond,
			_goalPos.y,
			_goalPos));
	_boids->goalHeight = _goalPos.y;
	_deployingBoids = false;
	_simulating = true;
	_sloMo = false;
	// init camera
	_camManipulator = FirstPersonManipulator::create();
	_camManipulator->setMoveRate(4.5f);
	
	setCameraManipulator(_camManipulator);
	addWidget(_camManipulator);
}


void App::onUserInput(UserInput *ui) {
	GApp::onUserInput(ui); // needed for widgets to advance (camera manipulators, GUIs)

	if (ui->keyPressed(GKey('1'))) {
		_viewRoadMap = !_viewRoadMap;
	}

	if (ui->keyDown(GKey('o'))) { // add obstacles with o
		int x = ui->mouseXY().x;
		int y = ui->mouseXY().y;
		Ray selectRay = activeCamera()->worldRay(x,y, renderDevice->viewport());
		bool hitSphere = false;
		int sphereIndex = -1;
		for (unsigned int i=0; i < _scene->_discs.size(); i++) {
			Sphere s(Convert::to3D(_scene->_discs[i].pos), _scene->_discs[i].radius);
			if ( !std::isinf(selectRay.intersectionTime(s)) ) {
				hitSphere = true;
				sphereIndex = i;
				break;
			}
		}

		if (hitSphere) {
			_scene->_discs[sphereIndex].radius += 0.01f;
		} else {
			Plane groundPlane(Vector3(0,1,0), Point3(0,0,0));
			Vector3 intersect = selectRay.intersection(groundPlane);
			_scene->addSphere(Convert::to2D(intersect) , 0.1f);
			sphereIndex = _scene->_discs.size() - 1;
		}
		if (_prm->updateGraphAfterNewSphere(sphereIndex)) {
			// the function returns true if a change was made
			_prm->fromGoalSearch(_goalNode);
		}
	}

	if (ui->keyPressed(GKey('p'))) {
		_simulating = !_simulating;
	}

	if (ui->keyPressed(GKey('9'))) {
		_sloMo = !_sloMo;
	}

	if (ui->keyPressed(GKey('r'))) {
		// seed rand so you get different results each time.
		srand( time(NULL) );
		Vector2 range = _scene->topRight - _scene->botLeft;
		bool foundNewGoal = false;
		while ( !foundNewGoal ) {
			double t = ((double) rand() / (RAND_MAX));
			float x = _scene->botLeft.x +  t * range.x;
			t = ((double) rand() / (RAND_MAX));
			float z = _scene->botLeft.y + t * range.y;
			t = ((double) rand() / (RAND_MAX));
			float y = t * (_maxHeight - 2) + 2 ;
			Vector3 p(x,y,z);
			if (_scene->collisionFreeDisc(Convert::to2D(p), _agentRadius)) {
				GraphNode* node = _prm->addNode(Convert::to2D(p));
				foundNewGoal = true;
				_goalNode = node;
				_goalPos = p;
				_boids->goalHeight = y;
			}
		}
		_prm->fromGoalSearch(_goalNode);
	}


	if (ui->keyDown(GKey(' '))) {
		_deployingBoids = true;
	} else {
		_deployingBoids = false;
	}

}


void App::onSimulation(RealTime rdt, SimTime sdt, SimTime idt) {
	GApp::onSimulation(rdt, sdt, idt); // need for widgets to advance (camera manipulators, GUIs)
	
	if (_simulating) {
		if (_sloMo) {
			rdt *= 0.1f;
		}
		if (_deployingBoids) {
			Point3 origin = activeCamera()->frame().translation;
			Vector3 direction = activeCamera()->frame().lookVector();
			const float offset = 1.f;
			origin = origin + offset * direction;
			_boids->addBoids(rdt, Ray(origin, direction));
		}
		_boids->doStep(rdt);
	}

}



void App::onGraphics3D(RenderDevice* rd, Array<shared_ptr<Surface> >& surface3D) {
	swapBuffers();
	rd->clear();
	_previewPlane->render3D(rd);
	_scene->render3D(rd);
	_boids->render3D(rd);

	// goal vis
	const float sphereRadius = 0.25f;
	Sphere goal(_goalPos, sphereRadius);
	Draw::sphere(goal, rd, Color3(.2,.3,.81), Color4::clear());


	// entire roadmap graph
	if (_viewRoadMap) {
		_prm->render3D(rd);
	}
}


void App::onGraphics2D(RenderDevice* rd, Array<Surface2D::Ref>& posed2D) {
	Surface2D::sortAndRender(rd, posed2D);

}




