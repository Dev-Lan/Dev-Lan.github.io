#include "PRM.hpp"

PRM::PRM(
	std::shared_ptr< Scene2D > scene,
	unsigned int numSamples,
	float neighborDist,
	float agentRadius
	) :
		_numNodes(numSamples),
		_neighborDistSquared(neighborDist * neighborDist),
		_agentRadius(agentRadius),
		_scene(scene)
{
	initGraph();
}

std::vector< GraphNode* > PRM::getPath(const Vector2& start, const Vector2& goal, float k)
{
	//todo
	// basically use A* in parent class
	GraphNode* startNode = new GraphNode(start);
	_nodes.push_back(startNode);
	std::vector< GraphNode* > neighbors = getNeighbors(_nodes.size()-1);
	for (unsigned int j=0; j < neighbors.size(); j++) {
		if (_scene->collisionFreeDisc(startNode->pos, neighbors[j]->pos, _agentRadius)) {
			startNode->children.push_back(neighbors[j]);
			neighbors[j]->children.push_back(startNode);
		}
	}

	GraphNode* goalNode = new GraphNode(goal);
	_nodes.push_back(goalNode);
	neighbors = getNeighbors(_nodes.size()-1);
	for (unsigned int j=0; j < neighbors.size(); j++) {
		if (_scene->collisionFreeDisc(goalNode->pos, neighbors[j]->pos, _agentRadius)) {
			goalNode->children.push_back(neighbors[j]);
			neighbors[j]->children.push_back(goalNode);
		}
	}
	// I was going to do weighted A*, but instead that function is actually just doing a simple BFS.
	return weightedAStar(startNode, goalNode);
}

void PRM::render3D(RenderDevice* rd) const
{
	// todo prettier rendering (low priority)
	// todo faster rendering (med priority)
	const float nodeRadius = 0.1f;
	for (unsigned int i=0; i < _nodes.size(); i++) {
		// nodes
		Sphere s(Convert::to3D(_nodes[i]->pos), nodeRadius);
		Draw::sphere(s, rd, Color4(.1f, .3f, .7f, 0.5f), Color4::clear());
		// edges
		for (unsigned int j=0; j < _nodes[i]->children.size(); j++) {
			// only draw to midpoint for debugging purposes (can confirm the edges are two ways this way)
			Vector3 midpoint = Convert::to3D( (_nodes[i]->pos + _nodes[i]->children[j]->pos) / 2.f );
			LineSegment ls = LineSegment::fromTwoPoints(Convert::to3D(_nodes[i]->pos), midpoint);
			Draw::lineSegment(ls, rd, Color4(.5,.5,.5,.5));
		}
	}
}

bool PRM::updateGraphAfterNewSphere(int sphereIndex)
{
	bool changeWasMade = false;
	for (unsigned int i=0; i < _nodes.size(); i++) {
		for (unsigned int j=0; j < _nodes[i]->children.size(); j++) {
			if ( ! _scene->collisionFreeDisc(_nodes[i]->pos, _nodes[i]->children[j]->pos, _agentRadius, sphereIndex) ) {
				// remove connection
				_nodes[i]->children[j] = _nodes[i]->children[ _nodes[i]->children.size()-1 ];
				_nodes[i]->children.pop_back();
				j--;
				changeWasMade = true;
			}
		}
	}
	return changeWasMade;
}

/// either returns the closest visible node, or the first within closeEnough distance. (I am just hoping for a little speedup here)
GraphNode* PRM::getCloseEnoughNode(const Vector2& v, float closeEnough, float agentRadius)
{
	float closeEnoughSquared = closeEnough * closeEnough;
	float smallestSquared = -1;
	GraphNode* closestNode = _nodes[0]; // if completely stuck give first node.
	for (unsigned int i=0; i < _nodes.size(); i++) {
		// if visible, 
		if (_scene->collisionFreeDisc(v, _nodes[i]->pos, agentRadius)) {
			Vector2 toNode = _nodes[i]->pos - v;
			float distSquared = toNode.dot(toNode);
			if (distSquared < closeEnoughSquared) {
				return _nodes[i];
			} else if (distSquared < smallestSquared || smallestSquared == -1) {
				smallestSquared = distSquared;
				closestNode = _nodes[i];
			}
		}
	}
	return closestNode;
}



void PRM::initGraph()
{
	// seed rand so you get different results each time.
	srand( time(NULL) );
	Vector2 range = _scene->topRight - _scene->botLeft;
	while ( _nodes.size() < _numNodes) {
		double t = ((double) rand() / (RAND_MAX));
		float x = _scene->botLeft.x +  t * range.x;
		t = ((double) rand() / (RAND_MAX));
		float y = _scene->botLeft.y + t * range.y;
		Vector2 p(x,y);
		if (_scene->collisionFreeDisc(p, _agentRadius)) {
			GraphNode* node = new GraphNode(x,y);
			_nodes.push_back(node);
		}
	}
	loadSpatialDataStructure();
	for (unsigned int i=0; i < _nodes.size(); i++) {
		std::vector< GraphNode* > neighbors = getNeighbors(i);
		for (unsigned int j=0; j < neighbors.size(); j++) {
			if (_scene->collisionFreeDisc(_nodes[i]->pos, neighbors[j]->pos, _agentRadius)) {
				// only connect one way to avoid duplication.
					// this could be optimized a little, but the simpler approach is always more likely to work.
				_nodes[i]->children.push_back(neighbors[j]);
			}
		}
	}

}

void PRM::loadSpatialDataStructure()
{
	// TODO
}

std::vector< GraphNode* > PRM::getNeighbors(unsigned int index, bool bruteForce) const
{
	std::vector< GraphNode* > result;
	if (bruteForce) {
		for (unsigned int i=0; i < _nodes.size(); i++) {
			if (i != index) {
				Vector2 v = _nodes[index]->pos - _nodes[i]->pos;
				if (v.dot(v) < _neighborDistSquared) {
					result.push_back(_nodes[i]);
				}
			}
		}
	} else {
		//todo
	}
	return result;
}


GraphNode* PRM::addNode(const Vector2& pos)
{
	GraphNode* newNode = new GraphNode(pos);
	_nodes.push_back(newNode);
	std::vector< GraphNode* > neighbors = getNeighbors(_nodes.size()-1);
	for (unsigned int j=0; j < neighbors.size(); j++) {
		if (_scene->collisionFreeDisc(newNode->pos, neighbors[j]->pos, _agentRadius)) {
			newNode->children.push_back(neighbors[j]);
			neighbors[j]->children.push_back(newNode);
		}
	}
	return newNode;
}