#pragma once
#include <math.h>
#include <time.h>
#include <G3D/G3DAll.h>
#include "SpatialGraph.hpp"
#include "Scene2D.hpp"
#include "Convert.hpp"

class PRM : public SpatialGraph {
public:
	PRM() {}
	PRM(
		std::shared_ptr< Scene2D > scene,
		unsigned int numSamples,
		float neighborDist,
		float agentRadius
		);

	/// finds goal from arbitrary start and end goal, k is the constant for weighted A*
	std::vector< GraphNode* > getPath(const Vector2& start, const Vector2& goal, float k=1);

	void render3D(RenderDevice* rd) const;

	bool updateGraphAfterNewSphere(int sphereIndex);

	/// either returns the closest visible node, or the first within closeEnough distance. (I am just hoping for a little speedup here)
	GraphNode* getCloseEnoughNode(const Vector2& v, float closeEnough, float agentRadius);

	/// add a new node to the graph at position
	GraphNode* addNode(const Vector2& pos);

protected:
	/// number of nodes sampled in your PRM
	unsigned int _numNodes;

	/// The size of your neighborhood when connecting nodes, squared
	float _neighborDistSquared;

	/// radius of disc agent you are creating a roadmap for
	float _agentRadius;

	/// scene you are planning around
	std::shared_ptr< Scene2D > _scene;

	// todo : spatial
	// typedef std::vector< GraphNode* > Bucket;
	// std::vector< std::vector< Bucket > > _gridLookup;

	void initGraph();

	void loadSpatialDataStructure();

	std::vector< GraphNode* > getNeighbors(unsigned int index, bool bruteForce=true) const;
};