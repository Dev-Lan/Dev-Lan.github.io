#pragma once
#include <map>
#include <unordered_set>
#include <G3D/G3DAll.h>

class GraphNode {
public:
	GraphNode() {	}
	GraphNode(
		float x,
		float y
		) :
			pos(x,y),
			toGoal(this),
			G(-1),
			H(-1)
	{

	}
	GraphNode(
		const Vector2& pos
		) :
			pos(pos),
			toGoal(this),
			G(-1),
			H(-1)
	{

	}

	Vector2 pos;
	std::vector< GraphNode* > children;
	GraphNode* toGoal; // use to store best path to goal, useful when doing from goal search
	// useful for search algorithm.
	float G;
	float H;
};

class SpatialGraph {
public:
	SpatialGraph() {	}

	// breaking rule of 3/5, lazy and constrained by time, because school.
	~SpatialGraph();

	/// returns shortest path using weighted A*, by default k=1 resulting in regular A*
	std::vector< GraphNode* > weightedAStar(GraphNode* start, GraphNode* goal, float k=1);

	/// helper function for creating path from dictionary lookup
	std::vector< GraphNode* > constructPath(std::map< GraphNode*, GraphNode* >& cameFrom, GraphNode* goalNode);

	/// starts at node and constructs shortest path form all nodes, in terms of edges traversed.
	void fromGoalSearch(GraphNode* goalNode);

protected:
	std::vector< GraphNode* > _nodes;

};