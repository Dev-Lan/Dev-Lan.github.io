#pragma once
#include <G3D/G3DAll.h>

/// simple particle class for convenience use in emitter
class Particle {
public:
	Vector3 pos;
	Vector3 vel;

	Particle(
		const Vector3& pos,
		const Vector3& vel
		) :
			pos(pos),
			vel(vel)
	{

	}
};