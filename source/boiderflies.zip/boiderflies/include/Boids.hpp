#pragma once
#include <G3D/G3DAll.h>
#include <assert.h>
#include "config.hpp"
#include "DiscEmitter.hpp"
#include "PRM.hpp"
#include "Scene2D.hpp"

class Boids
{
public:
	Boids();

	Boids(
		const std::shared_ptr< Scene2D >& scene, // scene with obstacles
		const std::shared_ptr< PRM >& prm, // roadmap
		const std::shared_ptr< Texture >& texture,
		float maxBoids = 1000,
		float maxSpeed = 10, // one ussain bolt
		float maxAccel = 10, // about one g
		float neighborDist = 0.5f,
		float boundingRadius = 0.1f,
		float emitterRadius = 0.2f,
		float particlesPerSecond = 10.f,
		float goalHeight = 10.f,
		const Vector3& currentGoal = Vector3(0,0,0)
		) :
			currentGoal(currentGoal),
			goalHeight(goalHeight),
			_maxSpeed(maxSpeed),
			_maxAccel(maxAccel),
			_neighborDistSquared(neighborDist * neighborDist),
			_boundingRadius(boundingRadius),
			_scene(scene),
			_prm(prm),
			_texture(texture),
			_maxBoids(maxBoids),
			_emitter(emitterRadius, particlesPerSecond, maxSpeed, 0.5f)
	{
		initGraphics();
		// could populate with some boids here.
	}

	/// add boids with your emitter
	void addBoids(float dt, const Ray& ray);

	/// run one simulation step
	void doStep(float dt);

	/// render the boids
	void render3D(RenderDevice* rd);

	/// all boids move towards this goal
	Vector3 currentGoal;

	/// height of goal, used for my hacky 2.5D planning
	float goalHeight;

protected:

	/// adds goal force to _accelerations
	void toGoal(int index);

	/// repulses ground and columns
	void avoidObstacles(int index);

	/// adds separation force to _accelerations
	void seperate(const Array< int >& neighbors, int index);

	/// adds alignment force to _accelerations
	void align(const Array< int >& neighbors, int index);

	/// adds cohesion force to _accelerations
	void addCohesion(const Array< int >& neighbors, int index);

	/// do forward euler integration step
	void doEulerStep(float dt);

	/// finds nearest neighbors indices of boid at index i
	Array< int > findNeighbors(int index);

	float _maxSpeed; // meters per second
	float _maxAccel; // meters per second^2
	float _neighborDistSquared;
	float _boundingRadius; // bounding sphere approximation of the boid

	Array< Vector3 > _positions; // current positions of all boids
	Array< Vector3 > _velocities;
	Array< Vector3 > _accelerations;
	Array< float > _cycle; // used to control how far through the flap animation to go
	Array< GraphNode* > _goals; // the current goal node of all points

	std::shared_ptr< Scene2D > _scene; // scene with obstacles
	std::shared_ptr< PRM > _prm; // roadmap
	std::shared_ptr< Texture > _texture; // texture on wing.

	int _maxBoids; // max number allowed, usefull for graphics card initialization

	DiscEmitter _emitter; // the deadly buttefly gun

	// stuff for rendering
	AttributeArray _posGPU; // positions of objects
	AttributeArray _headingGPU; // direction the boids are facing
	AttributeArray _cycleGPU; // used for flap animation
	IndexStream _indices;
	std::shared_ptr< VertexBuffer > _vbuf;

	void updateGraphicsCard();

	void initGraphics();
};