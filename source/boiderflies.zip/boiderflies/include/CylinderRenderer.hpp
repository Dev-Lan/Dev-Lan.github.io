#pragma once
#include <G3D/G3DAll.h>
#include "config.hpp"
// quick and dirty CylinderRenderer rendering class.
// renders simple axis aligned (only y) cylinderRenderers
class CylinderRenderer
{
public:
	CylinderRenderer()
	{
		initGeometry();
	}

	void render3D(RenderDevice* rd, const Vector3& offset, float height, float radius) const
	{
		rd->pushState();
		{
			Matrix3 scaler(radius, 0, 0,
							0, height, 0,
							0,0, radius);
  			rd->setObjectToWorldMatrix(rd->objectToWorldMatrix() * CoordinateFrame(scaler, offset));
			rd->setCullFace(CullFace::NONE);
			Args args;
			args.setAttributeArray("vert", _gpuVerts);
			args.setAttributeArray("norm", _gpuNorms);
			args.setAttributeArray("stripe", _gpuStripes);
			args.setIndexArray(_indices);
			args.setPrimitiveType(PrimitiveType::TRIANGLE_STRIP);
			LAUNCH_SHADER(BASIC_SHADER, args);
		}
		rd->popState();
	}

protected:
	void initGeometry()
	{
		const int resolution = 12;
		Array< Vector3 > verts;
		Array< Vector3 > norms;
		Array< int > indices;
		Array< float > stripes;
		int index = 0;
		for (int i=0; i < resolution; i++) {
			float theta = 2 * pi() * i / (float) resolution;
			float x = cos(theta);
			float z = sin(theta);
			// verts
			verts.append(Vector3(x,1,z));
			verts.append(Vector3(x,0,z));
			// norms, if I decide to use them
			norms.append(Vector3(x,0,z));
			norms.append(Vector3(x,0,z));
			// let's use a tri-strip
			indices.append(index++);
			indices.append(index++);
			// stipe hack
			stripes.append(i % 2);
			stripes.append(i % 2);
		}
		indices.append(0); // wrap all the way around
		indices.append(1);
		_vbuf = VertexBuffer::create(verts.length() * sizeof(Vector3) +
									 norms.length() * sizeof(Vector3) +
									 indices.length() * sizeof(int) +
									 stripes.length() * sizeof(float)
									, VertexBuffer::WRITE_ONCE);
		_gpuVerts = AttributeArray(verts, _vbuf);
		_gpuNorms = AttributeArray(norms, _vbuf);
		_gpuStripes = AttributeArray(stripes, _vbuf);
		_indices = IndexStream(indices, _vbuf);
	}
	AttributeArray _gpuVerts;
	AttributeArray _gpuNorms;
	AttributeArray _gpuStripes;
	IndexStream _indices;
	std::shared_ptr< VertexBuffer > _vbuf;
};