#pragma once
#include <G3D/G3DAll.h>
#include <iostream>
#include <sstream>
#include "PreviewPlane.hpp"
#include "AttemptTexture.hpp"
#include "PRM.hpp"
#include "Scene2D.hpp"
#include "Convert.hpp"
#include "Boids.hpp"

class App : public GApp {
public:
	
	App(const GApp::Settings& settings = GApp::Settings());
	
	virtual void onInit() override;

	virtual void onUserInput(UserInput *ui) override;
	virtual void onSimulation(RealTime rdt, SimTime sdt, SimTime idt) override;

	virtual void onGraphics3D(RenderDevice* rd, Array<shared_ptr<Surface> >& surface3D) override;
	virtual void onGraphics2D(RenderDevice* rd, Array<Surface2D::Ref>& surface2D) override;

protected:
	std::shared_ptr< PreviewPlane > _previewPlane;
	std::shared_ptr< Texture > _groundTileTexture;
	std::shared_ptr< Texture > _groundTileTextureNRM;

	/// boids simulator
	std::shared_ptr< Boids > _boids;
	bool _deployingBoids;
	bool _simulating;
	bool _sloMo;
	float _maxHeight; // max height of goals
	std::shared_ptr< Texture > _butterflyTexture;

	/// roadmap stuff
	bool _viewRoadMap;
	bool _viewPath;

	std::shared_ptr< Scene2D > _scene;
	std::shared_ptr< PRM > _prm;

	/// camera manipulator
	std::shared_ptr< FirstPersonManipulator > _camManipulator;

	// start goal
	// Vector2 _startPos;
	Vector3 _goalPos;
	GraphNode* _goalNode;
	// std::vector< GraphNode* > _currentPath;
	// used to animate agent
	// Vector2 _agentPos;
	float _agentRadius;
};
