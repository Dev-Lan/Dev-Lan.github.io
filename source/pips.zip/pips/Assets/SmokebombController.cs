﻿using UnityEngine;
using System.Collections;

public class SmokebombController : MonoBehaviour {
	private ParticleSystem particleSystem;

	// Use this for initialization
	void Start () {
		particleSystem = GetComponent<ParticleSystem> ();
	}
	
	// Destory the particle system when it is finished
	void Update () {
		if (particleSystem) {
			if (!particleSystem.IsAlive ()) {
				Destroy (gameObject);
			}
		}
	}
}
