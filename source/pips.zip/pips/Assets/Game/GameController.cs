﻿using UnityEngine;
using UnityEngine.UI;
using System.Linq;
using System.Collections;
using System.Collections.Generic;

public class GameController : MonoBehaviour {

	public static int[] playerWins = new int[InputController.numPlayers];

	public const float gameLength = 120f; // Length of a game in seconds
	private bool gameInProgress = false;
	private float timeRemaining;

	public static int goalCount = 4;
	private Dictionary<UserAgent, bool[]> goalStatus = new Dictionary<UserAgent, bool[]>();

	public UserAgent[] userAgents;
	public Text timerText;
	public crowdAI crowd;
	public InputController input;
	public GameObject timeUpObject;
	public PlayerUI[] playerUi;
	public GameObject endGame;
	public AudioSource musicAudio;

	public AudioClip hitGoalSound;
	public AudioClip endGameSound;
	public AudioClip drumRoll;
	public AudioClip showLoserSound;
	public AudioClip showWinnerSound;
	public AudioClip gameEndSound;

	void Start() {
		for (int i = 0; i < MenuController.readyPlayers.Length; i++) {
			if (!MenuController.readyPlayers[i]) {
				// Hide user agents that aren't in the game
				userAgents[i].gameObject.SetActive(false);
			} else {
				// Randomize start location
				Vector3? position = null;
				while (position == null) {
					position = crowd.getSpawnPoint(0);
				}
				userAgents[i].transform.position = (Vector3)position;
				// Start with all goals untouched
				goalStatus.Add(userAgents[i], new bool[goalCount]);
			}
		}

		timeRemaining = gameLength;
	}

	public void StartGame() {
		gameInProgress = true;
		crowd.SetStopped(false);
		input.stopped = false;
		musicAudio.Play();
	}

	public void HitGoal(int index, UserAgent agent) {
		bool[] goals = goalStatus[agent];
		if (!goals[index]) {
			goals[index] = true;
			agent.goalsTouched++;
			// End game if they hit all goals
			if (goals.All(b => b)) {
				StartCoroutine(EndGame(false));
			} else {
				PlayAudio(hitGoalSound);
			}
		}
	}

	void Update() {
		if (!gameInProgress)
			return;
		
		timeRemaining -= Time.deltaTime;
		if (timeRemaining <= 0f) {
			StartCoroutine(EndGame(true));
			return;
		}
			
		timerText.text = getHumanReadableTimeString(timeRemaining);
	}

	private static string getHumanReadableTimeString(float time) {
		int secondsRemaining = Mathf.CeilToInt(time);
		string secondsPart = (secondsRemaining % 60).ToString();
		if (secondsPart.Length == 1) {
			secondsPart = "0" + secondsPart;
		}
		secondsPart = secondsPart.Replace("1", " 1");
		string minutesPart = (secondsRemaining / 60).ToString();
		if (minutesPart == "0") {
			minutesPart = "";
		}
		minutesPart = minutesPart.Replace("1", " 1");
		return minutesPart + ":" + secondsPart;
	}

	IEnumerator EndGame(bool timeUp) {
		gameInProgress = false;
		timerText.gameObject.SetActive(false);
		crowd.SetStopped(true);
		input.stopped = true;

		PlayAudio(endGameSound);
		if (timeUp) {
			timeUpObject.SetActive(true);
		}
		yield return new WaitForSeconds(0.5f);
		musicAudio.Stop();
		yield return new WaitForSeconds(1f);
		PlayAudio(drumRoll);

		float fadeTimeRemaining = 4.2f;
		float prevTime = fadeTimeRemaining;
		Light[] lights = FindObjectsOfType<Light>();
		while (fadeTimeRemaining > 0f) {
			yield return null;
			fadeTimeRemaining -= Time.deltaTime;
			foreach (Light l in lights) {
				l.intensity = l.intensity / (prevTime / 4.2f) * (fadeTimeRemaining / 4.2f);
			}
			prevTime = fadeTimeRemaining;
		}
		foreach (Light l in lights) {
			l.enabled = false;
		}

		List<UserAgent> order = userAgents.OrderBy(a => a.goalsTouched).ToList();
		for (int i = 0; i < order.Count; i++) {
			int originalIndex = System.Array.IndexOf(userAgents, order[i]);
			if (!MenuController.readyPlayers[originalIndex])
				continue;
			
			Light light = order[i].GetComponentInChildren<Light>(true);
			light.gameObject.SetActive(true);
			if (i < order.Count - 1) {
				PlayAudio(showLoserSound);
			} else {
				playerWins[originalIndex]++;
				light.color = Color.green;
				PlayAudio(showWinnerSound);
			}
			playerUi[originalIndex].ShowPlayer(order[i], i == order.Count - 1);

			yield return new WaitForSeconds(0.75f);
		}
		input.stopped = false;
		endGame.SetActive(true);
		PlayAudio (gameEndSound);
	}

	private void PlayAudio(AudioClip audio) {
		AudioSource.PlayClipAtPoint(audio, Camera.main.transform.position);
	}
}
