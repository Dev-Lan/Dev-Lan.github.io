﻿using UnityEngine;
using System.Collections;

public class Lamppost : MonoBehaviour {

	public GameController game;
	public int index;

	//void OnCollisionEnter(Collision collision) {  // Use this if we want to make it solid again
	void OnTriggerEnter(Collider collider) {
		UserAgent agent = collider.gameObject.GetComponent<UserAgent>();
		if (agent != null) {
			game.HitGoal(index, agent);
		}
	}
}
