﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class NewGameController : MonoBehaviour, IInputHandler {

	public InputController input;
	public Animator fadeAnimator;

	void OnEnable() {
		for (int i = 0; i < InputController.numPlayers; i++) {
			input.AddHandler(i, this);
		}
	}

	void IInputHandler.Move(float x, float y) { }
	void IInputHandler.Stop() {	}
	void IInputHandler.Punch() {
		Fade();
	}
	void IInputHandler.Bomb() {
		Fade();
	}

	public void Fade() {
		fadeAnimator.enabled = true;
	}

	public void PlayAgain() {
		SceneManager.LoadScene("Main");
	}
}
