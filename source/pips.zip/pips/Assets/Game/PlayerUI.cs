﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class PlayerUI : MonoBehaviour {

	public GameObject name;
	public GameObject win;
	public Text goalCount;

	public void ShowPlayer(UserAgent agent, bool won) {
		this.GetComponent<RectTransform>().anchoredPosition = WorldToCanvas(GetComponentInParent<Canvas>(), agent.transform.position);
		win.SetActive(won);
		goalCount.text = agent.goalsTouched.ToString();

		this.gameObject.SetActive(true);
	}

	private static Vector2 WorldToCanvas(Canvas canvas, Vector3 worldPosition) {
		Vector2 viewportPosition = Camera.main.WorldToViewportPoint(worldPosition);
		RectTransform canvasRect = canvas.GetComponent<RectTransform>();

		return new Vector2(
			(viewportPosition.x * canvasRect.sizeDelta.x) - (canvasRect.sizeDelta.x * 0.5f),
			(viewportPosition.y * canvasRect.sizeDelta.y) - (canvasRect.sizeDelta.y * 0.5f));
	}
}
