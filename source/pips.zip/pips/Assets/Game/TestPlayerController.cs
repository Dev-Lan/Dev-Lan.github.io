﻿using UnityEngine;
using System.Collections;
using UnityStandardAssets.Characters.ThirdPerson;

public class TestPlayerController : MonoBehaviour, IInputHandler {

    public ThirdPersonCharacter m_Character; // A reference to the ThirdPersonCharacter on the object
	public InputController inputController;
	public int playerNum;
	public int numberOfSmokebombs = 1;

	private Fist fist;

	void Start() {
		inputController.AddHandler(playerNum, this);
		fist = GetComponentInChildren<Fist>();
	}

	void IInputHandler.Move(float x, float y) {
		const float moveFactor = 0.4f;
		Vector3 moveVector = new Vector3 (x, 0, y).normalized * moveFactor;
		m_Character.Move (moveVector, false, false);
	}

	void IInputHandler.Stop() {
		m_Character.Move (new Vector3(0,0,0), false, false);
	}

	void IInputHandler.Punch() {
		m_Character.Punch();
		fist.Punch();
	}

	void IInputHandler.Bomb() {
		if (numberOfSmokebombs > 0) {
			GameObject smokebomb = Instantiate (Resources.Load ("Smokebomb", typeof(GameObject))) as GameObject;
			smokebomb.transform.position = transform.position;
			numberOfSmokebombs--;
		}
	}
}