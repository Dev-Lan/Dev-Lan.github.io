﻿using UnityEngine;
using System.Collections;

public interface IInputHandler {

	void Move(float x, float y);
	void Stop();
	void Punch();
	void Bomb();
}
