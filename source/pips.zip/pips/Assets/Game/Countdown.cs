﻿using UnityEngine;
using System.Collections;

public class Countdown : MonoBehaviour {

	public GameController game;
	public AudioClip beepLow;
	public AudioClip beepHigh;

	public void StartGame() {
		game.StartGame();
	}

	public void PlayBeepLow() {
		AudioSource.PlayClipAtPoint(beepLow, Camera.main.transform.position);
	}

	public void PlayBeepHigh() {
		AudioSource.PlayClipAtPoint(beepHigh, Camera.main.transform.position);
	}
}
