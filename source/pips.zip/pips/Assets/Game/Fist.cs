﻿using UnityEngine;
using System.Collections;

public class Fist : MonoBehaviour {

	public GameController game;
	public AudioClip hitSound;
	public AudioClip missSound;
	public AudioClip deathSound;

	Collider fistCollider;
	bool hit;

	void Start() {
		fistCollider = GetComponent<Collider>();
		fistCollider.enabled = false;
	}

	public void Punch() {
		fistCollider.enabled = true;
		hit = false;
		StartCoroutine(fistTimer());
	}

	private IEnumerator fistTimer() {
		yield return null;
		yield return null;
		yield return null;
		fistCollider.enabled = false;
		if (hit) {
			AudioSource.PlayClipAtPoint(hitSound, transform.position);
			yield return new WaitForSeconds(0.1f);
			AudioSource.PlayClipAtPoint(deathSound, transform.position);
		} else {
			AudioSource.PlayClipAtPoint(missSound, transform.position);
		}
	}

	void OnTriggerEnter(Collider collider) {
		if (hit)
			return;
		
		UserAgent agent = collider.gameObject.GetComponent<UserAgent>();
		if (agent != null) {
			hit = true;
			agent.Die();
			return;
		}
		Agent agent2 = collider.gameObject.GetComponent<Agent>();
		if (agent2 != null) {
			hit = true;
			agent2.Die();
			return;
		}
	}
}
