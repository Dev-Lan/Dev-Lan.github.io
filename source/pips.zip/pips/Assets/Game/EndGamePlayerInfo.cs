﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class EndGamePlayerInfo : MonoBehaviour {

	public int playerNum;
	public Text winCount;

	void Start() {
		if (!MenuController.readyPlayers[playerNum]) {
			gameObject.SetActive(false);
		} else {
			winCount.text = GameController.playerWins[playerNum].ToString();
		}
	}
}
