﻿using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;

public class InputController : MonoBehaviour {

	public const int numPlayers = 4;

	public bool stopped = true;

	private const string inputHorizontal = "Horizontal";
	private const string inputVertical = "Vertical";

	private static KeyCode[][] punchKeys = new KeyCode[][] {
		new KeyCode[] { KeyCode.Joystick1Button0, KeyCode.Period },
		new KeyCode[] { KeyCode.Joystick2Button0, KeyCode.E },
		new KeyCode[] { KeyCode.Joystick3Button0 },
		new KeyCode[] { KeyCode.Joystick4Button0 }
	};

	private static KeyCode[][] bombKeys = new KeyCode[][] {
		new KeyCode[] { KeyCode.Joystick1Button1, KeyCode.Comma },
		new KeyCode[] { KeyCode.Joystick2Button1, KeyCode.Q },
		new KeyCode[] { KeyCode.Joystick3Button1 },
		new KeyCode[] { KeyCode.Joystick4Button1 }
	};

	private List<IInputHandler>[] handlers;

	public void AddHandler(int player, IInputHandler handler) {
		if (player < 0 || player >= numPlayers) {
			Debug.LogWarning("Tried to add handler for invalid player: " + player);
			return;
		}
		handlers[player].Add(handler);
	}

	public void RemoveHandler(int player, IInputHandler handler) {
		if (player < 0 || player >= numPlayers) {
			Debug.LogWarning("Tried to remove handler for invalid player: " + player);
			return;
		}
		handlers[player].Remove(handler);
	}

	void Awake() {
		handlers = new List<IInputHandler>[numPlayers];
		for (int i = 0; i < numPlayers; i++) {
			handlers[i] = new List<IInputHandler>();
		}
	}

	void Update() {
		for (int i = 0; i < numPlayers; i++) {
			if (stopped) {
				forEachHandler(i, h => h.Stop());
				continue;
			}

			float x = Input.GetAxisRaw(inputHorizontal + i.ToString());
			float y = Input.GetAxisRaw(inputVertical + i.ToString());
			if (x != 0 || y != 0) {
				forEachHandler(i, h => h.Move(x, y));
			} else {
				forEachHandler(i, h => h.Stop());
			}

			foreach (KeyCode key in punchKeys[i]) {
				if (Input.GetKeyDown(key)) {
					forEachHandler(i, h => h.Punch());
				}
			}

			foreach (KeyCode key in bombKeys[i]) {
				if (Input.GetKeyDown(key)) {
					forEachHandler(i, h => h.Bomb());
				}
			}
		}
	}

	void forEachHandler(int player, Action<IInputHandler> action) {
		foreach (IInputHandler handler in handlers[player]) {
			action(handler);
		}
	}
}
