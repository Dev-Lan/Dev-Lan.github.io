﻿using UnityEngine;
using System.Collections;
//TODO:: clean up initial agent parameters
	// possibly use settings struct like in c++
//TODO:: animated characters
	// could use Mixamo
//TODO:: obstacle avoidance
//TODO:: path planning


// This is the overall crowd controller class
public class crowdAI : MonoBehaviour {

	public double changeRateMin;
	public float changeRateMax;

	public AreaGen[] spawnAreas;

	public int maxNumberOfAgents;
	private int numberOfAgents;

	public System.Collections.Generic.List<Agent> agents;
	public System.Collections.Generic.List<UserAgent> userAgents;

	public Mesh agentMesh;
	public Mesh userAgentMesh;
	private int agentID;

	private double timeUntilChange;

	// Use this for initialization
	void Start () {
		updatetimeUntilChange();
		agentID = 0;
		initializeUserAgents ();
		while(numberOfAgents < maxNumberOfAgents)
		{
			attemptToSpawnAgent();
		}
	}
	
	// Update is called once per frame
	void Update () {
		float dt = Time.deltaTime;
		timeUntilChange -= dt;
		if (timeUntilChange < 0) {
			
			//get a new goal
			var rnd = new System.Random (System.DateTime.Now.Millisecond);
			int areaIndex = rnd.Next(0,spawnAreas.Length);
			Vector3 newGoal = spawnAreas[areaIndex].getGoalPoint();
			
			//update a random agent's goal to the new goal
			int agentsIndex = rnd.Next(0, agents.Count);
			agents[agentsIndex].setGoal(newGoal);
			//reset timer
			updatetimeUntilChange();
		}
	}

	public void SetStopped(bool stopped) {
		foreach (Agent agent in agents) {
			agent.stopped = stopped;
			if (!stopped) {
				//get a new goal
				int areaIndex = Random.Range(0,spawnAreas.Length);
				Vector3 newGoal = spawnAreas[areaIndex].getGoalPoint();
				agent.setGoal(newGoal);
			}
		}
	}

	private void updatetimeUntilChange() {
		var rnd = new System.Random(System.DateTime.Now.Millisecond);
		timeUntilChange = rnd.NextDouble()*(changeRateMax - changeRateMin) + changeRateMin;
	}

	private void initializeUserAgents() {
//		UserAgent ua = new GameObject ("UserAgent0").AddComponent<UserAgent>();
//		Vector3 pos = new Vector3 (0, 0, 0);
//		ua.Initialize(this, pos, 0.5f);
//		userAgents.Add (ua);
//	
//		ua = new GameObject ("UserAgent1").AddComponent<UserAgent>();
//		pos = new Vector3 (1, 0, 0);
//		ua.Initialize(this, pos, 0.5f);
//		userAgents.Add (ua);
//
//		ua = new GameObject ("UserAgent2").AddComponent<UserAgent>();
//		pos = new Vector3 (0, 0, 1);
//		ua.Initialize(this, pos, 0.5f);
//		userAgents.Add (ua);
//
//		ua = new GameObject ("UserAgent3").AddComponent<UserAgent>();
//		pos = new Vector3 (1, 0, 1);
//		ua.Initialize(this, pos, 0.5f);
//		userAgents.Add (ua);
	}

	private void attemptToSpawnAgent() {
		// Tries to spawn an agent in a spawn area, if the position
		// it picks would cause a collision it doesn't spawn the agent.
		var rnd = new System.Random (System.DateTime.Now.Millisecond);
		int areaIndex = rnd.Next (0, spawnAreas.Length);
		Vector3 position = getSpawnPoint(areaIndex);

		int StationaryOrNo = rnd.Next(0,2);
		Vector3 goal = new Vector3 (0,0,0);
		if (StationaryOrNo == 1)
		{
			goal = spawnAreas [areaIndex].getGoalPoint ();
		}
		else
		{
			goal = position;
		}
		float prefSpeed = 1.4f;
		GameObject agent = Instantiate(Resources.Load("Agent", typeof(GameObject))) as GameObject;
		agent.transform.name = "Agent";

		Agent a = agent.GetComponent<Agent> ();
		a.Initialize (this, (Vector3)position, goal, prefSpeed, ref agents, ref userAgents, agentID);
		numberOfAgents++;
		agentID++;
		agents.Add (a);
	}

	public Vector3 getSpawnPoint(int areaIndex) {
		float radius = 0.5f;
		Vector3 position = spawnAreas [areaIndex].getSpawnPoint ();
		bool collisionFree = true;
		for (int i=0; collisionFree && i < agents.Count; ++i) {
			float radiusSquared = agents[i].getRadius() + radius;
			radiusSquared = radiusSquared * radiusSquared;
			Vector3 diffVect = agents[i].getPosition() - position;
			if ( radiusSquared > diffVect.sqrMagnitude )
				collisionFree = false;
		}
		for (int i=0; collisionFree && i < userAgents.Count; ++i) {
			float radiusSquared = userAgents[i].getRadius() + radius;
			radiusSquared = radiusSquared * radiusSquared;
			Vector3 diffVect = userAgents[i].getPosition() - position;
			if ( radiusSquared > diffVect.sqrMagnitude )
				collisionFree = false;
		}
		if (collisionFree)
		{
			return position;
		}
		return getSpawnPoint(areaIndex);
	}

	public void destroyAgent() {
		numberOfAgents--;
	}	
}