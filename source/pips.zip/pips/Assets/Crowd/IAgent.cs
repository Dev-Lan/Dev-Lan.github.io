﻿using UnityEngine;
using System.Collections;

public interface IAgent {
	Vector3 getPosition();
	Vector3 getVel();
	float getRadius();
	
}