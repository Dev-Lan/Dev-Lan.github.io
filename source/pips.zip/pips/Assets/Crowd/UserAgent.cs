﻿using UnityEngine;
using System.Collections;
using UnityStandardAssets.Characters.ThirdPerson;

[RequireComponent(typeof(AudioSource))]
[System.Serializable]
public class UserAgent : MonoBehaviour, IAgent {
	private Mesh mesh;
	public Vector3 position;
	public float radius;
	public Vector3 vel;
	public Vector3 getPosition() { return position; }
	public Vector3 getVel() { return vel; }
	public float getRadius() { return radius; }
	public int goalsTouched = 0;
	
	// radius etc

	ThirdPersonCharacter character;
	
	void Start () {
//		gameObject.AddComponent<MeshRenderer> ();
//		gameObject.AddComponent<MeshFilter>().mesh = mesh;
//		position = new Vector3 (0, 0, 0);

		
//		gameObject.GetComponent<MeshRenderer>().material = new Material(Shader.Find("Specular"));
		
//		Color randColor = new Color(0.0f, 1.0f, 0.0f);
//		gameObject.GetComponent<MeshRenderer>().material.color = randColor;
		//aud.PlayOneShot(ding, 1f); //uncomment if you wanna verify sound works
		
		character = GetComponent<ThirdPersonCharacter>();
	}
	
	// Update is called once per frame
	void Update () {
//		Vector3 newPosition = this.position;
//		// this input code is for testing/debugging purposes only, it is hacky and bad.
//		// in the VR system you would replace with your own position
//		float constantUpdateDist = 0.025f; // this isn't ideal, but it's only for testing/debugging
//		if (Input.GetKey ("w") || Input.GetKey ("up")) {
//			newPosition.z += constantUpdateDist;
//		}
//		if (Input.GetKey ("s") || Input.GetKey ("down")) {
//			newPosition.z -= constantUpdateDist;
//		}
//		if (Input.GetKey ("a") || Input.GetKey ("left")) {
//			newPosition.x -= constantUpdateDist;
//		}
//		if (Input.GetKey ("d") || Input.GetKey ("right")) {
//			newPosition.x += constantUpdateDist;
//		}
//		
//		setNewPosition (newPosition);
		Vector3 newPosition = this.transform.position;
		vel = (newPosition - this.position) / Time.deltaTime;
		this.position.y = -1;
		this.position = this.transform.position;
	}

	public void setNewPosition(Vector3 newPos) {
		vel = newPos - this.position;
		vel /= Time.deltaTime;
		this.position = newPos;
		this.transform.position = this.position;
		
	}
	
	public void Initialize(crowdAI parent, Vector3 position, float radius) {
//		this.position = position;
//		this.mesh = parent.userAgentMesh;
//		this.radius = radius;
		this.transform.parent = parent.transform;
	}

	public void Die() {
		character.Die();
	}
}