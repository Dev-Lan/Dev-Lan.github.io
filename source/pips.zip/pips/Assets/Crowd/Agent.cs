﻿using UnityEngine;
using System.Collections;
//namespace UnityStandardAssets.Characters.ThirdPerson

//[RequireComponent(typeof (NavMeshAgent))]
[RequireComponent(typeof (UnityStandardAssets.Characters.ThirdPerson.ThirdPersonCharacter))]
[RequireComponent(typeof(AudioSource))]

public class Agent : MonoBehaviour, IAgent {
	// variables used in crowd algorithm
	public System.Collections.Generic.List<Agent> agents;
	public System.Collections.Generic.List<UserAgent> userAgents;
	private Vector3 position;
	public Vector3 getPosition() { return position; }
	private Vector3 vel;
	public Vector3 getVel() { return vel; }
	private Vector3 force;
	private Vector3 vPref;
	private bool waiting;
	public bool stopped = true;
	
	private Vector3 goal;
	public void setGoal(Vector3 newGoal) { goal = newGoal; waiting = false;}
	private float prefSpeed;
	private float goalRadius = 1.0f;
	private float goalRadiusSquared;
	private float radius = 1f;
	public float getRadius() { return radius; }
	private float maxAccel = 20.0f;
	private float neighborDist = 10.0f;
	private float neighborDistSquared;
	// constants used for TTC algorithm,
	private float k = 1.5f;
	private float ksi = 0.54f;
	private float m = 2.0f;
	private float t0 = 3.0f;
	
	private float EPS = 0.0001f;
	private UnityStandardAssets.Characters.ThirdPerson.ThirdPersonCharacter character;
	
	// variables for unity
	public int id;
	private Mesh mesh;
	private crowdAI parent;

	// character controller
//	public NavMeshAgent agent { get; private set; } // the navmesh agent required for the path finding
//	public UnityStandardAssets.Characters.ThirdPerson.ThirdPersonCharacter character { get; private set; } // the character we are controlling
//	public Transform target; // target to aim for

	
	void Start () {
		character = GetComponent<UnityStandardAssets.Characters.ThirdPerson.ThirdPersonCharacter> ();
	}
	
	// Update is called once per frame
	void Update () {
		
		vPref = goal - position;
		float distanceSquaredToGoal = vPref.sqrMagnitude;
		
		// get your preferred velocity to the correct speed.
		vPref.Normalize ();
		vPref *= prefSpeed;
		
		if (distanceSquaredToGoal < goalRadiusSquared) {
			/*// Destroy the object, remove from agent list.
			parent.destroyAgent();
			agents.Remove(this);
			Destroy (this.gameObject);*/
			waiting = true;
		}
		
		if (!waiting && !stopped) {
			// while we may want different behaviour while waiting, this apparently is needed for the other agents to not hit the waiting agents.
			computeForces ();

			updateAgent ();
		} else {
			// The character isn't moving
			character.Move(new Vector3(0.0f, 0.0f, 0.0f), false, false);
		}

	}

	public void Die() {
		character.Die();
	}

	void computeForces () {
		force = vPref - vel;
		force /= ksi;
		// get nearest neighbors
		System.Collections.Generic.List<IAgent> neighbors = getNeighbors();
		
		// add collision avoidance forces of each agent
		foreach (IAgent otherAgent in neighbors) {
			
			Vector3 diffVec = otherAgent.getPosition() - this.position;
			float distanceSquared = diffVec.sqrMagnitude;
			float radiusSquared = otherAgent.getRadius() + this.radius;
			radiusSquared = radiusSquared * radiusSquared;
			
			if (distanceSquared != this.radius) {
			
				// agents are in a collision, apply this hack to resolve collisions
				if (distanceSquared < radiusSquared) {
					radiusSquared = 0.99f * distanceSquared;
				}
				Vector3 w = otherAgent.getPosition() - this.position;
				Vector3 v = this.vel - otherAgent.getVel();
				float a = Vector3.Dot(v,v);
				float b = Vector3.Dot (w, v);
				float c = Vector3.Dot (w,w) - radiusSquared;
				float discr = b*b - a*c;
				if (discr > .0f && (a < -EPS || a > EPS) ) {
					discr = Mathf.Sqrt(discr);
					float t = (b - discr) / a;
					// if collision will happen, i.e. time to collision is greater than 0 update forces
					if (t > 0 ) {
						force += -this.k * Mathf.Exp(-t/this.t0)*(v - (b*v - a*w)/discr)/(a* Mathf.Pow(t,this.m))*(this.m/t + 1/this.t0);		
					}
				}
			}
		}
		//TODO:: add obstacles
	}
	
	void updateAgent() {
		Vector3 acceleration = Vector3.ClampMagnitude (this.force, this.maxAccel);
		this.vel = this.vel + acceleration * Time.deltaTime;
		this.position = this.position + this.vel * Time.deltaTime;
		this.position.y = -1;

		// Perform the character animation
		character.Move (position - transform.position, false, false);
	}
	
	System.Collections.Generic.List<IAgent> getNeighbors() {
		System.Collections.Generic.List<IAgent> nn = new System.Collections.Generic.List<IAgent> ();
		foreach (Agent a in agents) {			
			if (a.id != this.id) {
				Vector3 diffVec = a.position - this.position;
				float distanceSquared = diffVec.sqrMagnitude;
				if (distanceSquared < this.neighborDistSquared) {
					nn.Add(a);
				}
			}
		}
		foreach (UserAgent ua in userAgents) {			
			Vector3 diffVec = ua.getPosition() - this.position;
			float distanceSquared = diffVec.sqrMagnitude;
			if (distanceSquared < this.neighborDistSquared) {
				nn.Add(ua);
			}
		}
		return nn;
	}
	
	public void Initialize(crowdAI parent, Vector3 position, Vector3 goal, float prefSpeed, ref System.Collections.Generic.List<Agent> agents, ref System.Collections.Generic.List<UserAgent> userAgents, int agentID) {
		mesh = parent.agentMesh;
		transform.parent = parent.transform;
		this.position = position;
		this.transform.position = position;
		this.goal = goal;
		this.prefSpeed = prefSpeed;
		this.parent = parent;
		this.agents = agents;
		this.userAgents = userAgents;
		this.id = agentID;
		
		this.goalRadiusSquared = this.goalRadius * this.goalRadius;
		this.neighborDistSquared = this.neighborDist * this.neighborDist;
	}
	
}