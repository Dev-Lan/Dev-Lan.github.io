﻿using UnityEngine;
using System.Collections;

[System.Serializable]
public class AreaGen {
	public Vector3 spawnBottomLeft;
	public Vector3 spawnTopRight;
	
	public Vector3 goalBottomLeft;
	public Vector3 goalTopRight;
	
	private System.Random rnd = new System.Random(System.DateTime.Now.Millisecond);
	
	public Vector3 getSpawnPoint() {
		float x = (float) rnd.NextDouble () * (spawnTopRight.x - spawnBottomLeft.x) + spawnBottomLeft.x;
		float y = (float) rnd.NextDouble () * (spawnTopRight.y - spawnBottomLeft.y) + spawnBottomLeft.y;
		float z = (float) rnd.NextDouble () * (spawnTopRight.z - spawnBottomLeft.z) + spawnBottomLeft.z;
		Vector3 position = new Vector3 (x, y, z);
		return position;
	}
	
	public Vector3 getGoalPoint() {
		float x = (float) rnd.NextDouble () * (goalTopRight.x - goalBottomLeft.x) + goalBottomLeft.x;
		float y = (float) rnd.NextDouble () * (goalTopRight.y - goalBottomLeft.y) + goalBottomLeft.y;
		float z = (float) rnd.NextDouble () * (goalTopRight.z - goalBottomLeft.z) + goalBottomLeft.z;
		Vector3 goal = new Vector3 (x, y, z);
		return goal;
	}
}