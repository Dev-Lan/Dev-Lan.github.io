﻿using UnityEngine;
using System.Collections;
using System.Linq;

public class MenuController : MonoBehaviour {

	public GameObject startGameText;
	public GameObject fadeOut;
	public InputController input;

	public AudioClip[] playerReadySounds;
	public AudioClip beginGameSound;

	// Initialize like this so that the game still works when you play the main scene directly
	public static bool[] readyPlayers = new bool[] { true, true, true, true };

	void Awake() {
		readyPlayers = new bool[InputController.numPlayers];
	}

	void OnEnable() {
		for (int i = 0; i < readyPlayers.Length; i++) {
			readyPlayers[i] = false;
		}
		input.stopped = false;
	}

	public void PlayerReady(int player) {
		if (readyPlayers[player] && canStartGame()) {
			fadeOut.SetActive(true);
			AudioSource.PlayClipAtPoint(beginGameSound, Camera.main.transform.position);
			StartCoroutine(WaitThenLoadGame());
		} else if (!readyPlayers[player]) {
			AudioSource.PlayClipAtPoint(playerReadySounds[readyPlayers.Count(b => b)], Camera.main.transform.position);
			readyPlayers[player] = true;
			if (canStartGame()) {
				startGameText.SetActive(true);
			}
		}
	}

	public bool canStartGame() {
		return readyPlayers.Count(b => b) >= 2;
	}

	private IEnumerator WaitThenLoadGame() {
 		yield return new WaitForSeconds(1f);
		Application.LoadLevel("Main");
	}
}
