﻿using UnityEngine;
using System.Collections;

public class PlayerStatus : MonoBehaviour, IInputHandler {

	public MenuController menu;
	public InputController input;
	public GameObject waitingText;
	public GameObject readyText;
	public int playerNum;

	void Start() {
		input.AddHandler(playerNum, this);
	}

	void IInputHandler.Move(float x, float y) { }
	void IInputHandler.Stop() {	}
	void IInputHandler.Punch() {
		Ready();
	}
	void IInputHandler.Bomb() {
		Ready();
	}

	void Ready() {
		waitingText.SetActive(false);
		readyText.SetActive(true);
		menu.PlayerReady(playerNum);
	}
}
